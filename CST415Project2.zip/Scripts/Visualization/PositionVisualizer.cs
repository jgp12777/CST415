using UnityEngine;

/// <summary>
/// Handles visual feedback for defense positions during CSP solving
/// Manages highlighting, flashing, and state visualization
/// </summary>
public class PositionVisualizer : MonoBehaviour
{
    [Header("Visual State Materials")]
    public Material defaultMaterial;        // Normal state
    public Material highlightMaterial;      // Yellow - being evaluated (MCV selected)
    public Material assignedMaterial;       // Green - successfully assigned
    public Material evaluatingMaterial;     // Cyan - trying units (LCV ordering)
    public Material flashMaterial;          // Red - domain reduction
    public Material wipeoutMaterial;        // Dark red - domain wipeout

    [Header("References")]
    private Renderer positionRenderer;
    private DefensePosition position;

    [Header("Flash Animation")]
    private bool isFlashing = false;
    private float flashTimer = 0f;
    private float flashDuration = 0.3f;
    private Material flashReturnMaterial;

    [Header("Glow Effect")]
    private bool isGlowing = false;
    private float glowIntensity = 0f;
    private float glowSpeed = 3f;

    void Awake()
    {
        positionRenderer = GetComponent<Renderer>();
        position = GetComponent<DefensePosition>();

        if (positionRenderer == null)
        {
            Debug.LogError($"PositionVisualizer on {gameObject.name} requires a Renderer component!");
        }
    }

    void Update()
    {
        // Handle flash animation
        if (isFlashing)
        {
            flashTimer -= Time.deltaTime;
            if (flashTimer <= 0f)
            {
                EndFlash();
            }
        }

        // Handle glow pulsing
        if (isGlowing && positionRenderer != null)
        {
            glowIntensity = Mathf.PingPong(Time.time * glowSpeed, 1f);
            
            if (positionRenderer.material.HasProperty("_EmissionColor"))
            {
                Color emissionColor = Color.yellow * glowIntensity;
                positionRenderer.material.SetColor("_EmissionColor", emissionColor);
            }
        }
    }

    /// <summary>
    /// Show position as being selected by MCV heuristic
    /// Yellow highlight with pulsing glow
    /// </summary>
    public void ShowSelected()
    {
        if (positionRenderer != null && highlightMaterial != null)
        {
            positionRenderer.material = highlightMaterial;
            StartGlow();
        }
        
        Debug.Log($"[Visual] {position?.positionName ?? gameObject.name} - Selected (MCV)");
    }

    /// <summary>
    /// Show position as being evaluated (trying units via LCV)
    /// Cyan highlight
    /// </summary>
    public void ShowEvaluating()
    {
        if (positionRenderer != null && evaluatingMaterial != null)
        {
            positionRenderer.material = evaluatingMaterial;
        }
        
        Debug.Log($"[Visual] {position?.positionName ?? gameObject.name} - Evaluating (LCV)");
    }

    /// <summary>
    /// Show position as successfully assigned
    /// Green material
    /// </summary>
    public void ShowAssigned()
    {
        StopGlow();
        
        if (positionRenderer != null && assignedMaterial != null)
        {
            positionRenderer.material = assignedMaterial;
        }
        
        Debug.Log($"[Visual] {position?.positionName ?? gameObject.name} - Assigned");
    }

    /// <summary>
    /// Return to default visual state
    /// </summary>
    public void ShowDefault()
    {
        StopGlow();
        
        if (positionRenderer != null && defaultMaterial != null)
        {
            positionRenderer.material = defaultMaterial;
        }
    }

    /// <summary>
    /// Flash red to indicate domain reduction (forward checking)
    /// </summary>
    public void FlashDomainReduction()
    {
        if (positionRenderer != null && flashMaterial != null)
        {
            flashReturnMaterial = positionRenderer.material;
            positionRenderer.material = flashMaterial;
            isFlashing = true;
            flashTimer = flashDuration;
        }
        
        Debug.Log($"[Visual] {position?.positionName ?? gameObject.name} - Domain reduced (flash)");
    }

    /// <summary>
    /// Show domain wipeout state (no available units)
    /// Dark red with warning
    /// </summary>
    public void ShowDomainWipeout()
    {
        StopGlow();
        
        if (positionRenderer != null && wipeoutMaterial != null)
        {
            positionRenderer.material = wipeoutMaterial;
        }
        
        Debug.LogWarning($"[Visual] {position?.positionName ?? gameObject.name} - Domain Wipeout!");
    }

    /// <summary>
    /// End flash animation and return to previous material
    /// </summary>
    void EndFlash()
    {
        isFlashing = false;
        
        if (positionRenderer != null && flashReturnMaterial != null)
        {
            positionRenderer.material = flashReturnMaterial;
        }
    }

    /// <summary>
    /// Start pulsing glow effect
    /// </summary>
    void StartGlow()
    {
        isGlowing = true;
        glowIntensity = 0f;
        
        if (positionRenderer != null && positionRenderer.material.HasProperty("_EmissionColor"))
        {
            positionRenderer.material.EnableKeyword("_EMISSION");
        }
    }

    /// <summary>
    /// Stop pulsing glow effect
    /// </summary>
    void StopGlow()
    {
        isGlowing = false;
        glowIntensity = 0f;
        
        if (positionRenderer != null && positionRenderer.material.HasProperty("_EmissionColor"))
        {
            positionRenderer.material.SetColor("_EmissionColor", Color.black);
        }
    }

    /// <summary>
    /// Set custom flash duration
    /// </summary>
    public void SetFlashDuration(float duration)
    {
        flashDuration = duration;
    }

    /// <summary>
    /// Set custom glow speed
    /// </summary>
    public void SetGlowSpeed(float speed)
    {
        glowSpeed = speed;
    }
}
