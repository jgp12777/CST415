using System.Collections;
using UnityEngine;

/// <summary>
/// Handles all animations for defensive units during CSP solving
/// Movement, highlighting, and visual feedback
/// </summary>
public class UnitAnimator : MonoBehaviour
{
    [Header("Animation Settings")]
    public float movementSpeed = 2f;
    public float arcHeight = 1.5f;
    public float rotationSpeed = 5f;

    [Header("Visual Effects")]
    public Material normalMaterial;
    public Material highlightMaterial;
    public Material placedMaterial;

    [Header("References")]
    private Renderer unitRenderer;
    private DefensiveUnit unit;

    [Header("Animation State")]
    private bool isAnimating = false;
    private Vector3 targetPosition;
    private Quaternion targetRotation;

    void Awake()
    {
        unitRenderer = GetComponent<Renderer>();
        unit = GetComponent<DefensiveUnit>();
    }

    /// <summary>
    /// Animate unit moving from current position to target with smooth arc
    /// </summary>
    public IEnumerator AnimateMoveTo(Vector3 destination, float speed = -1f)
    {
        if (speed < 0) speed = movementSpeed;
        
        isAnimating = true;
        Vector3 startPos = transform.position;
        Vector3 endPos = destination;
        
        float distance = Vector3.Distance(startPos, endPos);
        float duration = distance / speed;
        float elapsed = 0f;

        // Calculate arc
        Vector3 midPoint = (startPos + endPos) / 2f;
        midPoint.y += arcHeight;

        Debug.Log($"[Animator] {unit?.GetDisplayName() ?? gameObject.name} moving to {destination}");

        while (elapsed < duration)
        {
            elapsed += Time.deltaTime;
            float t = elapsed / duration;
            
            // Smooth ease in-out
            float smoothT = Mathf.SmoothStep(0f, 1f, t);
            
            // Calculate position on arc using quadratic bezier curve
            Vector3 p0 = startPos;
            Vector3 p1 = midPoint;
            Vector3 p2 = endPos;
            
            Vector3 m1 = Vector3.Lerp(p0, p1, smoothT);
            Vector3 m2 = Vector3.Lerp(p1, p2, smoothT);
            Vector3 currentPos = Vector3.Lerp(m1, m2, smoothT);
            
            transform.position = currentPos;
            
            // Rotate to face direction of movement
            if (elapsed < duration - 0.1f)
            {
                Vector3 direction = (endPos - startPos).normalized;
                if (direction != Vector3.zero)
                {
                    Quaternion lookRotation = Quaternion.LookRotation(direction);
                    transform.rotation = Quaternion.Slerp(transform.rotation, lookRotation, Time.deltaTime * rotationSpeed);
                }
            }
            
            yield return null;
        }

        transform.position = endPos;
        isAnimating = false;
        
        Debug.Log($"[Animator] {unit?.GetDisplayName() ?? gameObject.name} reached destination");
    }

    /// <summary>
    /// Animate unit moving directly without arc (for backtracking)
    /// </summary>
    public IEnumerator AnimateMoveToLinear(Vector3 destination, float speed = -1f)
    {
        if (speed < 0) speed = movementSpeed * 1.5f; // Faster for backtrack
        
        isAnimating = true;
        Vector3 startPos = transform.position;
        
        float distance = Vector3.Distance(startPos, destination);
        float duration = distance / speed;
        float elapsed = 0f;

        Debug.Log($"[Animator] {unit?.GetDisplayName() ?? gameObject.name} backtracking to {destination}");

        while (elapsed < duration)
        {
            elapsed += Time.deltaTime;
            float t = elapsed / duration;
            
            transform.position = Vector3.Lerp(startPos, destination, t);
            yield return null;
        }

        transform.position = destination;
        isAnimating = false;
        
        Debug.Log($"[Animator] {unit?.GetDisplayName() ?? gameObject.name} backtrack complete");
    }

    /// <summary>
    /// Highlight unit (yellow glow) when being evaluated by LCV
    /// </summary>
    public void Highlight()
    {
        if (unitRenderer != null && highlightMaterial != null)
        {
            unitRenderer.material = highlightMaterial;
        }
        
        Debug.Log($"[Animator] {unit?.GetDisplayName() ?? gameObject.name} - Highlighted");
    }

    /// <summary>
    /// Remove highlight and return to normal appearance
    /// </summary>
    public void Unhighlight()
    {
        if (unitRenderer != null && normalMaterial != null)
        {
            unitRenderer.material = normalMaterial;
        }
    }

    /// <summary>
    /// Show unit as successfully placed (green tint)
    /// </summary>
    public void ShowPlaced()
    {
        if (unitRenderer != null && placedMaterial != null)
        {
            unitRenderer.material = placedMaterial;
        }
        
        Debug.Log($"[Animator] {unit?.GetDisplayName() ?? gameObject.name} - Shown as placed");
    }

    /// <summary>
    /// Pulse animation for successful placement
    /// </summary>
    public IEnumerator PulseOnPlacement()
    {
        Vector3 originalScale = transform.localScale;
        Vector3 targetScale = originalScale * 1.2f;
        
        float duration = 0.3f;
        float elapsed = 0f;

        // Expand
        while (elapsed < duration)
        {
            elapsed += Time.deltaTime;
            float t = elapsed / duration;
            transform.localScale = Vector3.Lerp(originalScale, targetScale, t);
            yield return null;
        }

        elapsed = 0f;

        // Contract
        while (elapsed < duration)
        {
            elapsed += Time.deltaTime;
            float t = elapsed / duration;
            transform.localScale = Vector3.Lerp(targetScale, originalScale, t);
            yield return null;
        }

        transform.localScale = originalScale;
    }

    /// <summary>
    /// Shake animation for constraint violation or backtracking
    /// </summary>
    public IEnumerator ShakeOnFailure()
    {
        Vector3 originalPos = transform.position;
        float shakeDuration = 0.3f;
        float shakeIntensity = 0.1f;
        float elapsed = 0f;

        while (elapsed < shakeDuration)
        {
            elapsed += Time.deltaTime;
            
            float x = originalPos.x + Random.Range(-shakeIntensity, shakeIntensity);
            float z = originalPos.z + Random.Range(-shakeIntensity, shakeIntensity);
            
            transform.position = new Vector3(x, originalPos.y, z);
            
            yield return null;
        }

        transform.position = originalPos;
    }

    /// <summary>
    /// Rotate unit to face a specific position
    /// </summary>
    public IEnumerator RotateToFace(Vector3 targetPos, float duration = 0.5f)
    {
        Vector3 direction = (targetPos - transform.position).normalized;
        direction.y = 0; // Keep rotation on horizontal plane
        
        if (direction == Vector3.zero) yield break;
        
        Quaternion startRotation = transform.rotation;
        Quaternion endRotation = Quaternion.LookRotation(direction);
        
        float elapsed = 0f;

        while (elapsed < duration)
        {
            elapsed += Time.deltaTime;
            float t = elapsed / duration;
            transform.rotation = Quaternion.Slerp(startRotation, endRotation, t);
            yield return null;
        }

        transform.rotation = endRotation;
    }

    /// <summary>
    /// Float animation (bobbing up and down) while waiting
    /// </summary>
    public IEnumerator FloatWhileWaiting(float amplitude = 0.2f, float frequency = 1f)
    {
        Vector3 startPos = transform.position;
        float time = 0f;

        while (!isAnimating)
        {
            time += Time.deltaTime * frequency;
            float yOffset = Mathf.Sin(time) * amplitude;
            transform.position = new Vector3(startPos.x, startPos.y + yOffset, startPos.z);
            yield return null;
        }

        transform.position = startPos;
    }

    /// <summary>
    /// Check if currently animating
    /// </summary>
    public bool IsAnimating()
    {
        return isAnimating;
    }

    /// <summary>
    /// Stop all animations immediately
    /// </summary>
    public void StopAllAnimations()
    {
        StopAllCoroutines();
        isAnimating = false;
    }
}
