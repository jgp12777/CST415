using System.Collections.Generic;
using System.Linq;
using UnityEngine;

/// <summary>
/// Centralized constraint validation for the Fortress Defense CSP
/// Implements all constraint checks in one place for clarity and testing
/// </summary>
public class ConstraintValidator : MonoBehaviour
{
    /// <summary>
    /// CONSTRAINT C1: Unit Availability Constraint
    /// Each unit can only be assigned to one position per wave (all-different constraint)
    /// </summary>
    public bool ValidateUnitAvailability(DefensiveUnit unit, Dictionary<DefensePosition, DefensiveUnit> currentAssignments)
    {
        // Check if unit is already assigned to any position
        foreach (var assignment in currentAssignments)
        {
            if (assignment.Value == unit)
            {
                Debug.LogWarning($"C1 Violation: {unit.GetDisplayName()} already assigned to {assignment.Key.positionName}");
                return false;
            }
        }

        return true;
    }

    /// <summary>
    /// CONSTRAINT C2: Position Suitability Constraint
    /// Unit type must be compatible with position type
    /// - Archers → Walls OR Towers
    /// - Catapults → Outside Walls
    /// - Knights → Gates
    /// </summary>
    public bool ValidatePositionSuitability(DefensiveUnit unit, DefensePosition position)
    {
        bool isCompatible = false;

        switch (position.positionType)
        {
            case DefensePosition.PositionType.Wall:
            case DefensePosition.PositionType.Tower:
                // Only archers can go on walls and towers
                isCompatible = (unit.unitType == DefensiveUnit.UnitType.Archer);
                break;

            case DefensePosition.PositionType.Gate:
                // Only knights can defend gates
                isCompatible = (unit.unitType == DefensiveUnit.UnitType.Knight);
                break;

            case DefensePosition.PositionType.OutsideWalls:
                // Only catapults go outside walls
                isCompatible = (unit.unitType == DefensiveUnit.UnitType.Catapult);
                break;
        }

        if (!isCompatible)
        {
            Debug.LogWarning($"C2 Violation: {unit.unitType} cannot be placed at {position.positionType}");
        }

        return isCompatible;
    }

    /// <summary>
    /// CONSTRAINT C3: Timing Constraint (Simplified)
    /// All assignments must complete before enemy arrival
    /// For this implementation, we assume all assignments can complete in time
    /// (Could be extended to check: current_time + deployment_time < arrival_time)
    /// </summary>
    public bool ValidateTimingConstraint(DefensiveUnit unit, DefensePosition position, float currentTime)
    {
        // Simplified: always returns true
        // Real implementation would check: currentTime + unit.deploymentTime < position.enemyArrivalTime
        
        float assignmentCompletionTime = currentTime + unit.deploymentTime;
        
        if (assignmentCompletionTime >= position.enemyArrivalTime)
        {
            Debug.LogWarning($"C3 Violation: {unit.GetDisplayName()} cannot deploy in time for {position.positionName}");
            return false;
        }

        return true;
    }

    /// <summary>
    /// CONSTRAINT C4: Force Balance Constraint
    /// Every active attack route must have at least one defensive unit assigned
    /// (Checked at solution completion)
    /// </summary>
    public bool ValidateForceBalance(List<DefensePosition> positions, Dictionary<DefensePosition, DefensiveUnit> assignments)
    {
        // Get all positions under threat
        var threatenedPositions = positions.Where(p => p.isUnderThreat).ToList();

        // Check each threatened position has an assignment
        foreach (var position in threatenedPositions)
        {
            if (!assignments.ContainsKey(position))
            {
                Debug.LogWarning($"C4 Violation: Threatened position {position.positionName} has no defender");
                return false;
            }
        }

        return true;
    }

    /// <summary>
    /// CONSTRAINT C5: No Overlapping Assignments
    /// Each position can only hold one unit at a time (unary constraint)
    /// </summary>
    public bool ValidateNoOverlap(DefensePosition position, Dictionary<DefensePosition, DefensiveUnit> currentAssignments)
    {
        // Check if position already has an assignment
        if (currentAssignments.ContainsKey(position))
        {
            Debug.LogWarning($"C5 Violation: {position.positionName} already has {currentAssignments[position].GetDisplayName()} assigned");
            return false;
        }

        return true;
    }

    /// <summary>
    /// Validate all constraints for a potential assignment
    /// Returns true if all constraints satisfied
    /// </summary>
    public bool ValidateAllConstraints(
        DefensiveUnit unit,
        DefensePosition position,
        Dictionary<DefensePosition, DefensiveUnit> currentAssignments,
        float currentTime = 0f)
    {
        // Check all constraints in order
        if (!ValidateUnitAvailability(unit, currentAssignments))
            return false;

        if (!ValidatePositionSuitability(unit, position))
            return false;

        if (!ValidateNoOverlap(position, currentAssignments))
            return false;

        // Timing constraint (optional - simplified for initial version)
        // if (!ValidateTimingConstraint(unit, position, currentTime))
        //     return false;

        return true;
    }

    /// <summary>
    /// Validate complete solution satisfies all constraints
    /// </summary>
    public bool ValidateCompleteSolution(List<DefensePosition> positions, Dictionary<DefensePosition, DefensiveUnit> assignments)
    {
        // Check force balance
        if (!ValidateForceBalance(positions, assignments))
            return false;

        // Verify no duplicate unit assignments
        var assignedUnits = assignments.Values.ToList();
        var uniqueUnits = assignedUnits.Distinct().ToList();
        
        if (assignedUnits.Count != uniqueUnits.Count)
        {
            Debug.LogWarning("Solution violation: Some units assigned multiple times");
            return false;
        }

        Debug.Log("✓ Complete solution validates all constraints");
        return true;
    }
}
