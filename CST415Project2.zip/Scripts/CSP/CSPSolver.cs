using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

/// <summary>
/// Core CSP Solver for Fortress Defense
/// Implements Backtracking with Forward Checking, MCV, and LCV heuristics
/// Solves unit-to-position assignment problem with multiple constraints
/// </summary>
public class CSPSolver : MonoBehaviour
{
    [Header("References")]
    public GameManager gameManager;
    public UIManager uiManager;

    [Header("CSP Problem Definition")]
    public List<DefensePosition> positions = new List<DefensePosition>();  // VARIABLES
    public List<DefensiveUnit> availableUnits = new List<DefensiveUnit>(); // VALUES

    [Header("CSP State")]
    private Dictionary<DefensePosition, DefensiveUnit> assignments = new Dictionary<DefensePosition, DefensiveUnit>();
    private int backtrackCount = 0;
    private int nodesExplored = 0;

    [Header("Animation Settings")]
    public float placementAnimationSpeed = 5f;  // Faster (was 2f)
    public Vector3 stagingAreaPosition = new Vector3(-10f, 2f, 0f);
    public float selectionPauseTime = 0.2f;  // Pause when selecting position
    public float backtrackPauseTime = 0.1f;  // Pause when backtracking

    private bool isSolving = false;
    private ConstraintValidator constraintValidator;

    void Awake()
    {
        constraintValidator = gameObject.AddComponent<ConstraintValidator>();
    }

    /// <summary>
    /// Initialize domains for all positions based on unit-position compatibility
    /// DOMAIN INITIALIZATION: Each position gets compatible units
    /// </summary>
    public void InitializeDomains()
    {
        backtrackCount = 0;
        nodesExplored = 0;
        assignments.Clear();

        foreach (DefensePosition position in positions)
        {
            position.InitializeDomain(availableUnits);
            position.RestoreDefaultMaterial();
        }

        // Reset all units
        foreach (DefensiveUnit unit in availableUnits)
        {
            unit.Unassign();
            unit.Unhighlight();
            unit.transform.position = stagingAreaPosition;
        }

        Debug.Log($"CSP Initialized: {positions.Count} positions, {availableUnits.Count} units");
        Debug.Log($"Domain sizes: {string.Join(", ", positions.Select(p => $"{p.positionName}={p.GetDomainSize()}"))}");
    }

    /// <summary>
    /// Start the CSP solving process with visualization
    /// </summary>
    public void StartSolving()
    {
        if (isSolving)
        {
            Debug.LogWarning("Solver already running");
            return;
        }

        InitializeDomains();

        if (uiManager != null)
        {
            uiManager.UpdateStatus("Starting CSP Solver...");
            uiManager.UpdateBacktrackCount(0);
            uiManager.UpdateNodesExplored(0);
        }

        StartCoroutine(SolveCoroutine());
    }

    /// <summary>
    /// Main solving coroutine with visualization
    /// </summary>
    IEnumerator SolveCoroutine()
    {
        isSolving = true;
        bool success = false;

        Debug.Log("═══════════════════════════════════");
        Debug.Log("  STARTING CSP BACKTRACKING SEARCH");
        Debug.Log("═══════════════════════════════════");

        // Start backtracking search
        yield return StartCoroutine(BacktrackCoroutine(result => success = result));

        Debug.Log("═══════════════════════════════════");
        if (success)
        {
            Debug.Log("  ✓ SOLUTION FOUND!");
            Debug.Log($"  Backtracks: {backtrackCount}");
            Debug.Log($"  Nodes Explored: {nodesExplored}");
            Debug.Log("  Final Assignment:");
            foreach (var kvp in assignments)
            {
                Debug.Log($"    {kvp.Key.positionName} ← {kvp.Value.GetDisplayName()}");
            }

            if (uiManager != null)
            {
                uiManager.UpdateStatus("✓ Solution Found!");
            }

            // Show all positions as successfully assigned
            foreach (var position in positions)
            {
                position.ShowAssigned();
            }
        }
        else
        {
            Debug.Log("  ✗ NO SOLUTION EXISTS");
            Debug.Log($"  Backtracks: {backtrackCount}");
            Debug.Log($"  Nodes Explored: {nodesExplored}");
        }
        Debug.Log("═══════════════════════════════════");

        isSolving = false;

        // Notify GameManager that solving is complete
        if (gameManager != null)
        {
            gameManager.OnSolverComplete(success);
        }
    }

    /// <summary>
    /// Recursive backtracking algorithm with visualization
    /// Implements standard CSP backtracking with forward checking
    /// </summary>
    IEnumerator BacktrackCoroutine(System.Action<bool> callback)
    {
        nodesExplored++;

        // BASE CASE: All positions assigned - success!
        if (assignments.Count == positions.Count)
        {
            Debug.Log("✓ All positions assigned - solution complete!");
            callback(true);
            yield break;
        }

        // HEURISTIC: Most Constrained Variable (MCV)
        DefensePosition selectedPosition = SelectMostConstrainedPosition();

        if (selectedPosition == null)
        {
            Debug.LogWarning("No unassigned position available - should not reach here");
            callback(false);
            yield break;
        }

        // Check for domain wipeout BEFORE trying values
        if (selectedPosition.GetDomainSize() == 0)
        {
            Debug.Log($"✗ Domain wipeout detected for {selectedPosition.positionName} - backtracking");
            callback(false);
            yield break;
        }

        // Highlight current position being evaluated
        selectedPosition.Highlight();
        if (uiManager != null)
        {
            uiManager.UpdateStatus($"Assigning: {selectedPosition.positionName} (MCV)");
            uiManager.UpdatePositionStates(positions);
        }

        yield return new WaitForSeconds(selectionPauseTime);  // Configurable pause

        Debug.Log($"→ Selected {selectedPosition.positionName} (MCV: domain size = {selectedPosition.GetDomainSize()})");

        // HEURISTIC: Least Constraining Value (LCV)
        List<DefensiveUnit> orderedUnits = OrderUnitsByLCV(selectedPosition);

        Debug.Log($"  LCV ordering: {string.Join(", ", orderedUnits.Select(u => $"{u.GetDisplayName()}"))}");

        // Try each unit in LCV order
        for (int i = 0; i < orderedUnits.Count; i++)
        {
            DefensiveUnit unit = orderedUnits[i];

            Debug.Log($"  Trying: {selectedPosition.positionName} ← {unit.GetDisplayName()} (LCV rank {i + 1}/{orderedUnits.Count})");

            // Check all constraints
            if (IsAssignmentConsistent(selectedPosition, unit))
            {
                // Make assignment
                AssignmentState savedState = MakeAssignment(selectedPosition, unit);

                // Animate unit placement
                unit.Highlight();
                yield return StartCoroutine(AnimateUnitPlacement(unit, selectedPosition));
                unit.Unhighlight();

                // Forward checking
                Dictionary<DefensePosition, List<DefensiveUnit>> removedValues = ForwardCheck(unit);

                // Check for domain wipeout in remaining positions
                bool domainWipeout = CheckForDomainWipeout();

                if (!domainWipeout)
                {
                    // Update UI with current state
                    if (uiManager != null)
                    {
                        uiManager.UpdatePositionStates(positions);
                    }

                    // Recursively solve remaining positions
                    bool success = false;
                    yield return StartCoroutine(BacktrackCoroutine(result => success = result));

                    if (success)
                    {
                        selectedPosition.ShowAssigned();
                        callback(true);
                        yield break;
                    }

                    Debug.Log($"  ↩ Recursive call failed - backtracking");
                }
                else
                {
                    Debug.Log($"  ✗ Forward checking detected domain wipeout - backtracking");
                }

                // BACKTRACK: Undo assignment
                backtrackCount++;
                if (uiManager != null)
                {
                    uiManager.UpdateBacktrackCount(backtrackCount);
                    uiManager.UpdateNodesExplored(nodesExplored);
                }

                UndoAssignment(savedState, removedValues);
                yield return StartCoroutine(AnimateUnitRemoval(unit, selectedPosition));

                yield return new WaitForSeconds(backtrackPauseTime);  // Configurable backtrack pause
            }
            else
            {
                Debug.Log($"  ✗ Constraint violation - {unit.GetDisplayName()} inconsistent with {selectedPosition.positionName}");
            }
        }

        // All units tried, none worked - backtrack
        selectedPosition.RestoreDefaultMaterial();
        Debug.Log($"✗ No valid assignment found for {selectedPosition.positionName} - backtracking");
        callback(false);
    }

    /// <summary>
    /// MCV HEURISTIC: Select unassigned position with smallest domain
    /// Implements "fail-first" strategy to detect dead-ends early
    /// </summary>
    DefensePosition SelectMostConstrainedPosition()
    {
        DefensePosition mostConstrained = null;
        int minDomainSize = int.MaxValue;

        foreach (DefensePosition position in positions)
        {
            if (!assignments.ContainsKey(position))  // Unassigned
            {
                int domainSize = position.GetDomainSize();

                // Tie-breaking: prefer positions under more immediate threat
                if (domainSize < minDomainSize ||
                    (domainSize == minDomainSize && position.threatLevel > mostConstrained?.threatLevel))
                {
                    minDomainSize = domainSize;
                    mostConstrained = position;
                }
            }
        }

        return mostConstrained;
    }

    /// <summary>
    /// LCV HEURISTIC: Order units by least constraining first
    /// Chooses values that rule out fewest options for other positions
    /// </summary>
    List<DefensiveUnit> OrderUnitsByLCV(DefensePosition position)
    {
        List<DefensiveUnit> orderedUnits = new List<DefensiveUnit>(position.domain);

        // Calculate constraint count for each unit
        Dictionary<DefensiveUnit, int> constraintCounts = new Dictionary<DefensiveUnit, int>();

        foreach (DefensiveUnit unit in orderedUnits)
        {
            int count = 0;

            // Count how many unassigned positions would lose this unit
            foreach (DefensePosition otherPosition in positions)
            {
                if (!assignments.ContainsKey(otherPosition) && otherPosition != position)
                {
                    if (otherPosition.domain.Contains(unit))
                    {
                        count++;
                    }
                }
            }

            constraintCounts[unit] = count;
        }

        // Sort by constraint count (ascending - least constraining first)
        orderedUnits = orderedUnits.OrderBy(unit => constraintCounts[unit]).ToList();

        return orderedUnits;
    }

    /// <summary>
    /// Check if assigning unit to position satisfies all constraints
    /// </summary>
    bool IsAssignmentConsistent(DefensePosition position, DefensiveUnit unit)
    {
        // CONSTRAINT C1: Unit Availability - unit must not be already assigned
        if (unit.IsAssigned())
        {
            Debug.Log($"    Constraint C1 violation: {unit.GetDisplayName()} already assigned to {unit.assignedPosition.positionName}");
            return false;
        }

        // CONSTRAINT C2: Position Suitability - enforced by domain initialization
        // (units only in domain if compatible with position type)
        if (!position.domain.Contains(unit))
        {
            Debug.Log($"    Constraint C2 violation: {unit.GetDisplayName()} not compatible with {position.positionName}");
            return false;
        }

        // CONSTRAINT C3: Timing (simplified - could add deployment time checks)
        // For now, assume all assignments can complete in time

        // All constraints satisfied
        return true;
    }

    /// <summary>
    /// Make an assignment and save state for potential undo
    /// </summary>
    AssignmentState MakeAssignment(DefensePosition position, DefensiveUnit unit)
    {
        AssignmentState savedState = new AssignmentState
        {
            position = position,
            unit = unit
        };

        assignments[position] = unit;
        position.assignedUnit = unit;
        unit.AssignToPosition(position);
        position.UpdateDomainDisplay();

        Debug.Log($"    ✓ Assigned: {position.positionName} ← {unit.GetDisplayName()}");

        return savedState;
    }

    /// <summary>
    /// Forward checking: Remove assigned unit from all other positions' domains
    /// Returns dictionary of removed values for undo capability
    /// </summary>
    Dictionary<DefensePosition, List<DefensiveUnit>> ForwardCheck(DefensiveUnit assignedUnit)
    {
        Dictionary<DefensePosition, List<DefensiveUnit>> removedValues = new Dictionary<DefensePosition, List<DefensiveUnit>>();

        foreach (DefensePosition position in positions)
        {
            if (!assignments.ContainsKey(position))  // Unassigned positions
            {
                if (position.domain.Contains(assignedUnit))
                {
                    // Remove this unit from position's domain
                    position.RemoveFromDomain(assignedUnit);

                    // Track removal for undo
                    if (!removedValues.ContainsKey(position))
                    {
                        removedValues[position] = new List<DefensiveUnit>();
                    }
                    removedValues[position].Add(assignedUnit);

                    Debug.Log($"    FC: Removed {assignedUnit.GetDisplayName()} from {position.positionName} domain (now: {position.GetDomainSize()})");
                }
            }
        }

        return removedValues;
    }

    /// <summary>
    /// Check if any unassigned position has an empty domain (wipeout)
    /// </summary>
    bool CheckForDomainWipeout()
    {
        foreach (DefensePosition position in positions)
        {
            if (!assignments.ContainsKey(position) && position.GetDomainSize() == 0)
            {
                Debug.Log($"    ⚠ Domain wipeout: {position.positionName} has no available units");
                return true;
            }
        }
        return false;
    }

    /// <summary>
    /// Undo an assignment and restore domains
    /// </summary>
    void UndoAssignment(AssignmentState savedState, Dictionary<DefensePosition, List<DefensiveUnit>> removedValues)
    {
        // Remove assignment
        assignments.Remove(savedState.position);
        savedState.position.assignedUnit = null;
        savedState.unit.Unassign();
        savedState.position.UpdateDomainDisplay();
        savedState.position.RestoreDefaultMaterial();

        // Restore removed domain values
        foreach (var kvp in removedValues)
        {
            DefensePosition position = kvp.Key;
            List<DefensiveUnit> removed = kvp.Value;

            foreach (DefensiveUnit unit in removed)
            {
                position.AddToDomain(unit);
            }
        }

        Debug.Log($"    ↶ Undone: {savedState.position.positionName} ← {savedState.unit.GetDisplayName()}");
    }

    /// <summary>
    /// Animate unit moving from staging area to position
    /// </summary>
    IEnumerator AnimateUnitPlacement(DefensiveUnit unit, DefensePosition position)
    {
        Vector3 startPos = unit.transform.position;
        Vector3 targetPos = position.transform.position + Vector3.up * 0.8f;  // Slightly above position

        float elapsed = 0f;
        float duration = 1f / placementAnimationSpeed;

        while (elapsed < duration)
        {
            elapsed += Time.deltaTime;
            float t = elapsed / duration;

            // Smooth arc motion
            Vector3 currentPos = Vector3.Lerp(startPos, targetPos, t);
            currentPos.y += Mathf.Sin(t * Mathf.PI) * 1.5f;  // Arc height

            unit.transform.position = currentPos;
            yield return null;
        }

        unit.transform.position = targetPos;
    }

    /// <summary>
    /// Animate unit moving back to staging area (backtrack visualization)
    /// </summary>
    IEnumerator AnimateUnitRemoval(DefensiveUnit unit, DefensePosition position)
    {
        Vector3 startPos = unit.transform.position;
        Vector3 targetPos = stagingAreaPosition;

        float elapsed = 0f;
        float duration = 0.7f / placementAnimationSpeed;

        while (elapsed < duration)
        {
            elapsed += Time.deltaTime;
            float t = elapsed / duration;
            unit.transform.position = Vector3.Lerp(startPos, targetPos, t);
            yield return null;
        }

        unit.transform.position = targetPos;
    }

    /// <summary>
    /// Reset solver to initial state
    /// </summary>
    public void Reset()
    {
        StopAllCoroutines();
        isSolving = false;

        InitializeDomains();

        if (uiManager != null)
        {
            uiManager.UpdateStatus("Ready");
            uiManager.UpdateBacktrackCount(0);
            uiManager.UpdateNodesExplored(0);
            uiManager.UpdatePositionStates(positions);
        }

        Debug.Log("CSP Solver reset");
    }

    /// <summary>
    /// Helper class to store assignment state for backtracking
    /// </summary>
    private class AssignmentState
    {
        public DefensePosition position;
        public DefensiveUnit unit;
    }
}