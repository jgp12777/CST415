using UnityEngine;

/// <summary>
/// Represents an enemy unit attacking the fortress
/// Visual representation only - attacks automatically resolve based on CSP solution
/// </summary>
public class Enemy : MonoBehaviour
{
    [Header("Enemy Properties")]
    public WaveConfiguration.EnemyType enemyType;
    public string enemyName;
    public int health = 100;
    public float moveSpeed = 2f;

    [Header("Target")]
    public DefensePosition targetPosition;
    private Vector3 targetWorldPosition;
    private bool isMoving = false;
    private bool reachedTarget = false;

    [Header("Visual")]
    public Material enemyMaterial;
    private Renderer enemyRenderer;

    void Awake()
    {
        enemyRenderer = GetComponent<Renderer>();
    }

    /// <summary>
    /// Initialize enemy with target
    /// </summary>
    public void Initialize(WaveConfiguration.EnemyType type, DefensePosition target, Vector3 spawnPos)
    {
        enemyType = type;
        targetPosition = target;
        transform.position = spawnPos;

        if (target != null)
        {
            targetWorldPosition = target.transform.position;
            enemyName = $"{type} ? {target.positionName}";
        }

        SetupVisuals();
    }

    /// <summary>
    /// Setup visual appearance based on enemy type
    /// </summary>
    void SetupVisuals()
    {
        if (enemyRenderer == null) return;

        Color color = Color.red;
        Vector3 scale = Vector3.one;

        switch (enemyType)
        {
            case WaveConfiguration.EnemyType.Infantry:
                color = new Color(0.8f, 0.2f, 0.2f); // Dark red
                scale = new Vector3(0.5f, 0.7f, 0.5f);
                break;
            case WaveConfiguration.EnemyType.Archer:
                color = new Color(0.9f, 0.4f, 0.2f); // Orange-red
                scale = new Vector3(0.4f, 0.8f, 0.4f);
                break;
            case WaveConfiguration.EnemyType.Cavalry:
                color = new Color(0.6f, 0.1f, 0.1f); // Very dark red
                scale = new Vector3(0.7f, 0.8f, 0.7f);
                break;
            case WaveConfiguration.EnemyType.SiegeTower:
                color = new Color(0.4f, 0.3f, 0.2f); // Brown
                scale = new Vector3(1f, 2f, 1f);
                break;
            case WaveConfiguration.EnemyType.BatteringRam:
                color = new Color(0.5f, 0.4f, 0.3f); // Brown-gray
                scale = new Vector3(1.2f, 0.6f, 0.8f);
                break;
        }

        transform.localScale = scale;

        if (enemyMaterial != null)
        {
            enemyRenderer.material = enemyMaterial;
            enemyRenderer.material.color = color;
        }
    }

    /// <summary>
    /// Start moving toward target
    /// </summary>
    public void StartAttack()
    {
        isMoving = true;
        Debug.Log($"[Enemy] {enemyName} starting attack");
    }

    void Update()
    {
        if (isMoving && !reachedTarget)
        {
            MoveTowardTarget();
        }
    }

    /// <summary>
    /// Move toward target position
    /// </summary>
    void MoveTowardTarget()
    {
        Vector3 direction = (targetWorldPosition - transform.position).normalized;
        transform.position += direction * moveSpeed * Time.deltaTime;

        // Rotate to face direction
        if (direction != Vector3.zero)
        {
            transform.rotation = Quaternion.LookRotation(direction);
        }

        // Check if reached target
        if (Vector3.Distance(transform.position, targetWorldPosition) < 0.5f)
        {
            ReachTarget();
        }
    }

    /// <summary>
    /// Called when enemy reaches target position
    /// </summary>
    void ReachTarget()
    {
        reachedTarget = true;
        isMoving = false;

        Debug.Log($"[Enemy] {enemyName} reached target!");

        // Check if position is defended
        if (targetPosition != null && targetPosition.IsAssigned())
        {
            Debug.Log($"[Enemy] {enemyName} DEFEATED by {targetPosition.assignedUnit.GetDisplayName()}");
            Die();
        }
        else
        {
            Debug.LogWarning($"[Enemy] {enemyName} BREACHED undefended position!");
            Breach();
        }
    }

    /// <summary>
    /// Enemy defeated by defender
    /// </summary>
    void Die()
    {
        // Visual effect
        if (enemyRenderer != null)
        {
            enemyRenderer.material.color = Color.gray;
        }

        // Destroy after delay
        Destroy(gameObject, 1f);
    }

    /// <summary>
    /// Enemy breached defenses (position undefended)
    /// </summary>
    void Breach()
    {
        // Flash red
        if (enemyRenderer != null)
        {
            enemyRenderer.material.color = Color.yellow;
        }

        // Stay visible as warning
        isMoving = false;
    }

    /// <summary>
    /// Get icon for UI display
    /// </summary>
    public string GetIcon()
    {
        switch (enemyType)
        {
            case WaveConfiguration.EnemyType.Infantry: return "K";
            case WaveConfiguration.EnemyType.Archer: return "B";
            case WaveConfiguration.EnemyType.Cavalry: return "H";
            case WaveConfiguration.EnemyType.SiegeTower: return "C";
            case WaveConfiguration.EnemyType.BatteringRam: return "R";
            default: return "!";
        }
    }
}