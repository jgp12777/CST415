using UnityEngine;

/// <summary>
/// Represents a defensive unit in the fortress (Archer, Catapult, or Knight)
/// Acts as a VALUE in CSP domains - units are assigned to position variables
/// </summary>
public class DefensiveUnit : MonoBehaviour
{
    // Unit type enumeration
    public enum UnitType
    {
        Archer,     // Long-range, walls/towers only
        Catapult,   // Siege weapon, outside walls only
        Knight      // Melee, gates only
    }

    [Header("Unit Identity")]
    public UnitType unitType;
    public string unitName;
    public int unitID;  // Unique identifier for this unit instance

    [Header("CSP State")]
    public DefensePosition assignedPosition = null;  // Current assignment (null if unassigned)
    public bool isAssigned = false;

    [Header("Unit Stats")]
    public float attackPower = 10f;
    public float attackRange = 5f;
    public float deploymentTime = 2f;  // Time needed to set up

    [Header("Visual Properties")]
    public Material defaultMaterial;
    public Material highlightMaterial;
    private Renderer unitRenderer;
    private Color originalColor;

    void Awake()
    {
        unitRenderer = GetComponent<Renderer>();
        if (unitRenderer != null && unitRenderer.material != null)
        {
            originalColor = unitRenderer.material.color;
        }
    }

    /// <summary>
    /// Highlights this unit (yellow glow) when being evaluated by CSP solver
    /// </summary>
    public void Highlight()
    {
        if (unitRenderer != null && highlightMaterial != null)
        {
            unitRenderer.material = highlightMaterial;
        }
    }

    /// <summary>
    /// Removes highlight from this unit
    /// </summary>
    public void Unhighlight()
    {
        if (unitRenderer != null && defaultMaterial != null)
        {
            unitRenderer.material = defaultMaterial;
        }
    }

    /// <summary>
    /// Returns true if this unit is currently assigned to a position
    /// </summary>
    public bool IsAssigned()
    {
        return isAssigned && assignedPosition != null;
    }

    /// <summary>
    /// Assign this unit to a position
    /// </summary>
    public void AssignToPosition(DefensePosition position)
    {
        assignedPosition = position;
        isAssigned = true;
    }

    /// <summary>
    /// Unassign this unit (for backtracking)
    /// </summary>
    public void Unassign()
    {
        assignedPosition = null;
        isAssigned = false;
    }

    /// <summary>
    /// Get display name with unit type and ID
    /// </summary>
    public string GetDisplayName()
    {
        return $"{unitType}-{unitID}";
    }

    /// <summary>
    /// Returns icon emoji for UI display
    /// </summary>
    public string GetIcon()
    {
        switch (unitType)
        {
            case UnitType.Archer: return "🏹";
            case UnitType.Catapult: return "🎯";
            case UnitType.Knight: return "⚔️";
            default: return "?";
        }
    }
}
