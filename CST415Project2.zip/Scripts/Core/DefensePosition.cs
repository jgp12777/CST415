using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Represents a defensive position in the fortress that requires unit assignment
/// Acts as a VARIABLE in the CSP formulation
/// </summary>
public class DefensePosition : MonoBehaviour
{
    // Position type enumeration (defines terrain/structure)
    public enum PositionType
    {
        Wall,          // Elevated defensive wall
        Tower,         // High vantage point
        Gate,          // Ground-level entrance
        OutsideWalls   // Open ground outside fortress
    }

    [Header("Position Identity")]
    public PositionType positionType;
    public string positionName;
    public int positionID;

    [Header("CSP Properties")]
    public List<DefensiveUnit> domain = new List<DefensiveUnit>();  // Available units for this position
    public DefensiveUnit assignedUnit = null;  // Currently assigned unit (null if unassigned)
    public int initialDomainSize = 0;  // Track original domain size for visualization

    [Header("Attack Route Properties")]
    public bool isUnderThreat = false;  // Is this position under attack this wave?
    public float threatLevel = 0f;      // Priority level for MCV tie-breaking
    public float enemyArrivalTime = 30f;  // When enemies arrive at this position

    [Header("Visual Properties")]
    public Material defaultMaterial;
    public Material highlightMaterial;
    public Material assignedMaterial;
    public Material flashMaterial;  // For domain elimination flash
    private Renderer positionRenderer;
    private float flashTimer = 0f;
    private bool isFlashing = false;

    [Header("UI Elements")]
    public GameObject domainSizeLabel;  // TextMeshPro label showing domain size
    private TMPro.TextMeshProUGUI domainText;

    void Awake()
    {
        positionRenderer = GetComponent<Renderer>();
        
        // Find domain size label if it exists
        if (domainSizeLabel != null)
        {
            domainText = domainSizeLabel.GetComponent<TMPro.TextMeshProUGUI>();
        }
    }

    void Update()
    {
        // Handle flash animation timing
        if (isFlashing)
        {
            flashTimer -= Time.deltaTime;
            if (flashTimer <= 0f)
            {
                isFlashing = false;
                RestoreDefaultMaterial();
            }
        }
    }

    /// <summary>
    /// Initialize domain with compatible units based on position type
    /// CONSTRAINT C2: Position Suitability
    /// </summary>
    public void InitializeDomain(List<DefensiveUnit> allUnits)
    {
        domain.Clear();

        foreach (DefensiveUnit unit in allUnits)
        {
            if (IsUnitCompatible(unit))
            {
                domain.Add(unit);
            }
        }

        initialDomainSize = domain.Count;
        UpdateDomainDisplay();
        
        Debug.Log($"{positionName}: Initialized domain with {domain.Count} compatible units");
    }

    /// <summary>
    /// Check if a unit type is compatible with this position type
    /// Implements CONSTRAINT C2: Position Suitability
    /// </summary>
    public bool IsUnitCompatible(DefensiveUnit unit)
    {
        switch (positionType)
        {
            case PositionType.Wall:
            case PositionType.Tower:
                // Archers can be placed on walls or towers
                return unit.unitType == DefensiveUnit.UnitType.Archer;
                
            case PositionType.Gate:
                // Knights defend gates
                return unit.unitType == DefensiveUnit.UnitType.Knight;
                
            case PositionType.OutsideWalls:
                // Catapults placed outside walls
                return unit.unitType == DefensiveUnit.UnitType.Catapult;
                
            default:
                return false;
        }
    }

    /// <summary>
    /// Returns true if this position is currently assigned a unit
    /// </summary>
    public bool IsAssigned()
    {
        return assignedUnit != null;
    }

    /// <summary>
    /// Get current domain size
    /// </summary>
    public int GetDomainSize()
    {
        return domain.Count;
    }

    /// <summary>
    /// Remove a unit from this position's domain (forward checking)
    /// </summary>
    public void RemoveFromDomain(DefensiveUnit unit)
    {
        if (domain.Contains(unit))
        {
            domain.Remove(unit);
            UpdateDomainDisplay();
            FlashRed();  // Visual feedback
            Debug.Log($"{positionName}: Removed {unit.GetDisplayName()} from domain. New size: {domain.Count}");
        }
    }

    /// <summary>
    /// Add a unit back to domain (restoring after backtrack)
    /// </summary>
    public void AddToDomain(DefensiveUnit unit)
    {
        if (!domain.Contains(unit) && IsUnitCompatible(unit))
        {
            domain.Add(unit);
            UpdateDomainDisplay();
            Debug.Log($"{positionName}: Restored {unit.GetDisplayName()} to domain. New size: {domain.Count}");
        }
    }

    /// <summary>
    /// Update the domain size display label
    /// </summary>
    public void UpdateDomainDisplay()
    {
        if (domainText != null)
        {
            if (IsAssigned())
            {
                domainText.text = $"✓ {assignedUnit.GetDisplayName()}";
                domainText.color = Color.green;
            }
            else if (domain.Count == 0)
            {
                domainText.text = "Domain: 0 ⚠️";
                domainText.color = Color.red;
            }
            else
            {
                domainText.text = $"Domain: {domain.Count}";
                domainText.color = Color.white;
            }
        }
    }

    /// <summary>
    /// Highlight this position (yellow glow) when being evaluated
    /// </summary>
    public void Highlight()
    {
        if (positionRenderer != null && highlightMaterial != null)
        {
            positionRenderer.material = highlightMaterial;
        }
    }

    /// <summary>
    /// Show as assigned (green)
    /// </summary>
    public void ShowAssigned()
    {
        if (positionRenderer != null && assignedMaterial != null)
        {
            positionRenderer.material = assignedMaterial;
        }
    }

    /// <summary>
    /// Restore default appearance
    /// </summary>
    public void RestoreDefaultMaterial()
    {
        if (positionRenderer != null && defaultMaterial != null)
        {
            positionRenderer.material = defaultMaterial;
        }
    }

    /// <summary>
    /// Flash red to indicate domain elimination
    /// </summary>
    public void FlashRed()
    {
        if (positionRenderer != null && flashMaterial != null)
        {
            positionRenderer.material = flashMaterial;
            isFlashing = true;
            flashTimer = 0.3f;
        }
    }

    /// <summary>
    /// Get position type as string for display
    /// </summary>
    public string GetPositionTypeString()
    {
        return positionType.ToString();
    }

    /// <summary>
    /// String representation for debugging
    /// </summary>
    public override string ToString()
    {
        return $"{positionName} ({positionType}, Domain: {domain.Count})";
    }
}
