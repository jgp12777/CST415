using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Handles player input for manual unit placement (optional feature)
/// Allows players to manually assign units before or instead of using CSP solver
/// </summary>
public class DefenseController : MonoBehaviour
{
    [Header("References")]
    public GameManager gameManager;
    public CSPSolver cspSolver;
    public Camera mainCamera;

    [Header("Manual Placement Settings")]
    public bool allowManualPlacement = false;  // Enable/disable manual mode
    public LayerMask positionLayer;  // Layer for clickable positions
    public LayerMask unitLayer;      // Layer for clickable units

    [Header("Current Selection")]
    private DefensiveUnit selectedUnit = null;
    private DefensePosition hoveredPosition = null;

    [Header("Visual Feedback")]
    public Material validPlacementMaterial;
    public Material invalidPlacementMaterial;
    private GameObject placementPreview;

    [Header("State")]
    private bool isManualMode = false;
    private Dictionary<DefensePosition, DefensiveUnit> manualAssignments = new Dictionary<DefensePosition, DefensiveUnit>();

    void Update()
    {
        if (!allowManualPlacement || !isManualMode) return;

        HandleMouseInput();
        UpdatePlacementPreview();
    }

    /// <summary>
    /// Enable manual placement mode
    /// </summary>
    public void EnableManualMode()
    {
        isManualMode = true;
        allowManualPlacement = true;
        manualAssignments.Clear();
        
        Debug.Log("[DefenseController] Manual placement mode enabled");
    }

    /// <summary>
    /// Disable manual placement mode
    /// </summary>
    public void DisableManualMode()
    {
        isManualMode = false;
        selectedUnit = null;
        hoveredPosition = null;
        
        if (placementPreview != null)
        {
            Destroy(placementPreview);
        }
        
        Debug.Log("[DefenseController] Manual placement mode disabled");
    }

    /// <summary>
    /// Handle mouse input for clicking units and positions
    /// </summary>
    void HandleMouseInput()
    {
        if (Input.GetMouseButtonDown(0))  // Left click
        {
            Ray ray = mainCamera.ScreenPointToRay(Input.mousePosition);
            RaycastHit hit;

            // Check if clicked on a unit
            if (Physics.Raycast(ray, out hit, 100f, unitLayer))
            {
                DefensiveUnit clickedUnit = hit.collider.GetComponent<DefensiveUnit>();
                if (clickedUnit != null && !clickedUnit.IsAssigned())
                {
                    SelectUnit(clickedUnit);
                }
            }
            // Check if clicked on a position (and have unit selected)
            else if (selectedUnit != null && Physics.Raycast(ray, out hit, 100f, positionLayer))
            {
                DefensePosition clickedPosition = hit.collider.GetComponent<DefensePosition>();
                if (clickedPosition != null)
                {
                    TryPlaceUnit(selectedUnit, clickedPosition);
                }
            }
        }

        // Right click to deselect
        if (Input.GetMouseButtonDown(1))
        {
            DeselectUnit();
        }

        // Track hovered position for preview
        UpdateHoveredPosition();
    }

    /// <summary>
    /// Select a unit for placement
    /// </summary>
    void SelectUnit(DefensiveUnit unit)
    {
        // Deselect previous
        if (selectedUnit != null)
        {
            selectedUnit.Unhighlight();
        }

        selectedUnit = unit;
        selectedUnit.Highlight();
        
        Debug.Log($"[DefenseController] Selected: {unit.GetDisplayName()}");
    }

    /// <summary>
    /// Deselect current unit
    /// </summary>
    void DeselectUnit()
    {
        if (selectedUnit != null)
        {
            selectedUnit.Unhighlight();
            selectedUnit = null;
            Debug.Log("[DefenseController] Unit deselected");
        }
    }

    /// <summary>
    /// Try to place selected unit at position
    /// </summary>
    void TryPlaceUnit(DefensiveUnit unit, DefensePosition position)
    {
        // Validate placement
        if (!IsPlacementValid(unit, position))
        {
            Debug.LogWarning($"[DefenseController] Invalid placement: {unit.GetDisplayName()} → {position.positionName}");
            // Could add audio feedback or visual shake here
            return;
        }

        // Make placement
        manualAssignments[position] = unit;
        position.assignedUnit = unit;
        unit.AssignToPosition(position);

        // Move unit to position
        unit.transform.position = position.transform.position + Vector3.up * 0.8f;
        
        // Visual feedback
        position.ShowAssigned();
        unit.Unhighlight();
        
        Debug.Log($"[DefenseController] Placed: {unit.GetDisplayName()} → {position.positionName}");

        // Deselect after placement
        selectedUnit = null;
    }

    /// <summary>
    /// Check if placement is valid according to CSP constraints
    /// </summary>
    bool IsPlacementValid(DefensiveUnit unit, DefensePosition position)
    {
        // Check if position already occupied
        if (position.IsAssigned())
        {
            Debug.LogWarning($"Position {position.positionName} already occupied");
            return false;
        }

        // Check if unit already assigned
        if (unit.IsAssigned())
        {
            Debug.LogWarning($"Unit {unit.GetDisplayName()} already assigned");
            return false;
        }

        // Check position suitability (C2)
        if (!position.IsUnitCompatible(unit))
        {
            Debug.LogWarning($"Unit type {unit.unitType} incompatible with position type {position.positionType}");
            return false;
        }

        return true;
    }

    /// <summary>
    /// Update which position is currently being hovered
    /// </summary>
    void UpdateHoveredPosition()
    {
        if (selectedUnit == null) return;

        Ray ray = mainCamera.ScreenPointToRay(Input.mousePosition);
        RaycastHit hit;

        DefensePosition newHovered = null;

        if (Physics.Raycast(ray, out hit, 100f, positionLayer))
        {
            newHovered = hit.collider.GetComponent<DefensePosition>();
        }

        if (newHovered != hoveredPosition)
        {
            // Unhighlight previous
            if (hoveredPosition != null && !hoveredPosition.IsAssigned())
            {
                hoveredPosition.RestoreDefaultMaterial();
            }

            hoveredPosition = newHovered;

            // Highlight new
            if (hoveredPosition != null && !hoveredPosition.IsAssigned())
            {
                if (IsPlacementValid(selectedUnit, hoveredPosition))
                {
                    hoveredPosition.Highlight();
                }
            }
        }
    }

    /// <summary>
    /// Update visual preview of placement
    /// </summary>
    void UpdatePlacementPreview()
    {
        if (selectedUnit == null || hoveredPosition == null)
        {
            if (placementPreview != null)
            {
                placementPreview.SetActive(false);
            }
            return;
        }

        // Create preview if doesn't exist
        if (placementPreview == null)
        {
            placementPreview = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            placementPreview.transform.localScale = Vector3.one * 0.5f;
            placementPreview.GetComponent<Collider>().enabled = false;
        }

        // Position preview
        placementPreview.SetActive(true);
        placementPreview.transform.position = hoveredPosition.transform.position + Vector3.up * 0.8f;

        // Color based on validity
        Renderer previewRenderer = placementPreview.GetComponent<Renderer>();
        if (IsPlacementValid(selectedUnit, hoveredPosition))
        {
            previewRenderer.material = validPlacementMaterial;
        }
        else
        {
            previewRenderer.material = invalidPlacementMaterial;
        }
    }

    /// <summary>
    /// Clear all manual assignments (reset)
    /// </summary>
    public void ClearManualAssignments()
    {
        foreach (var assignment in manualAssignments)
        {
            assignment.Key.assignedUnit = null;
            assignment.Value.Unassign();
            assignment.Key.RestoreDefaultMaterial();
        }

        manualAssignments.Clear();
        selectedUnit = null;
        
        Debug.Log("[DefenseController] Manual assignments cleared");
    }

    /// <summary>
    /// Get manual assignments (for validation or comparison)
    /// </summary>
    public Dictionary<DefensePosition, DefensiveUnit> GetManualAssignments()
    {
        return new Dictionary<DefensePosition, DefensiveUnit>(manualAssignments);
    }

    /// <summary>
    /// Validate current manual assignments against CSP constraints
    /// </summary>
    public bool ValidateManualAssignments()
    {
        if (cspSolver == null) return false;

        // Would call ConstraintValidator here
        // For now, simple check:
        
        // Check all threatened positions have defenders
        int assignedCount = manualAssignments.Count;
        int requiredCount = cspSolver.positions.FindAll(p => p.isUnderThreat).Count;

        if (assignedCount < requiredCount)
        {
            Debug.LogWarning($"[DefenseController] Incomplete: {assignedCount}/{requiredCount} positions defended");
            return false;
        }

        Debug.Log($"[DefenseController] Manual assignments valid: {assignedCount} positions defended");
        return true;
    }

    /// <summary>
    /// Compare manual solution to CSP solver solution
    /// </summary>
    public void CompareWithCSPSolution()
    {
        Debug.Log("[DefenseController] Comparing manual solution with CSP solver...");
        // Future: Show comparison UI, highlight differences
    }
}
