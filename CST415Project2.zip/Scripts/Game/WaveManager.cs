using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Manages wave progression, enemy spawning, and victory/defeat conditions
/// </summary>
public class WaveManager : MonoBehaviour
{
    [Header("Wave Configurations")]
    public List<WaveConfiguration> allWaves = new List<WaveConfiguration>();
    public int currentWaveIndex = 0;
    private WaveConfiguration currentWave;

    [Header("References")]
    public GameManager gameManager;
    public CSPSolver cspSolver;
    public CastleGenerator castleGenerator;
    public UIManager uiManager;

    [Header("Enemy Spawning")]
    public GameObject enemyPrefab;
    private List<Enemy> activeEnemies = new List<Enemy>();
    private bool enemiesSpawned = false;

    [Header("Unit Management")]
    private List<DefensiveUnit> allUnits = new List<DefensiveUnit>();
    public GameObject archerPrefab;
    public GameObject knightPrefab;
    public GameObject catapultPrefab;
    public Vector3 unitStagingArea = new Vector3(-10, 1, 0);

    [Header("Wave State")]
    private bool waveActive = false;
    private int enemiesDefeated = 0;
    private int enemiesBreached = 0;

    void Start()
    {
        // Don't load wave immediately - wait for GameManager
        // GameManager will trigger wave load after setup
    }

    /// <summary>
    /// Initialize - called by GameManager after it's ready
    /// </summary>
    public void Initialize()
    {
        if (allWaves.Count > 0)
        {
            LoadWave(0);
        }
        else
        {
            Debug.LogError("No waves configured! Add WaveConfiguration assets.");
        }
    }

    /// <summary>
    /// Load and setup a specific wave
    /// </summary>
    public void LoadWave(int waveIndex)
    {
        if (waveIndex < 0 || waveIndex >= allWaves.Count)
        {
            Debug.LogError($"Invalid wave index: {waveIndex}");
            return;
        }

        currentWaveIndex = waveIndex;
        currentWave = allWaves[waveIndex];

        // Store original unit counts before any modifications
        currentWave.StoreOriginalCounts();

        Debug.Log($"----------------------------------------");
        Debug.Log($"  LOADING WAVE {currentWave.waveNumber}: {currentWave.waveName}");
        Debug.Log($"  Difficulty: {currentWave.difficulty}");
        Debug.Log($"  Layout: {currentWave.castleLayout}");
        Debug.Log($"----------------------------------------");

        // Clear previous wave
        ClearWave();

        // Generate castle layout
        if (castleGenerator != null)
        {
            List<DefensePosition> positions = castleGenerator.GenerateCastle(currentWave);

            if (cspSolver != null)
            {
                cspSolver.positions = positions;
            }
        }

        // Spawn units for this wave
        SpawnUnits();

        // Update UI
        if (uiManager != null)
        {
            uiManager.UpdateWaveInfo(currentWave.waveNumber, allWaves.Count, currentWave.waveName);
        }

        waveActive = false;
        enemiesSpawned = false;
        enemiesDefeated = 0;
        enemiesBreached = 0;

        // Notify GameManager that wave is ready
        if (gameManager != null)
        {
            gameManager.SetGameState(GameManager.GameState.Planning);
        }
    }

    /// <summary>
    /// Spawn defensive units based on wave configuration
    /// </summary>
    void SpawnUnits()
    {
        ClearUnits();

        int unitID = 1;
        Vector3 spawnOffset = Vector3.zero;

        // Spawn Archers
        for (int i = 0; i < currentWave.archerCount; i++)
        {
            GameObject unitObj = Instantiate(archerPrefab, unitStagingArea + spawnOffset, Quaternion.identity);
            unitObj.name = $"Archer_{i + 1}";

            DefensiveUnit unit = unitObj.GetComponent<DefensiveUnit>();
            if (unit != null)
            {
                unit.unitType = DefensiveUnit.UnitType.Archer;
                unit.unitName = $"Archer-{unitID}";
                unit.unitID = unitID++;
            }

            allUnits.Add(unit);
            spawnOffset.z -= 1f;
        }

        // Spawn Knights
        spawnOffset = new Vector3(-2, 0, 0);
        for (int i = 0; i < currentWave.knightCount; i++)
        {
            GameObject unitObj = Instantiate(knightPrefab, unitStagingArea + spawnOffset, Quaternion.identity);
            unitObj.name = $"Knight_{i + 1}";

            DefensiveUnit unit = unitObj.GetComponent<DefensiveUnit>();
            if (unit != null)
            {
                unit.unitType = DefensiveUnit.UnitType.Knight;
                unit.unitName = $"Knight-{unitID}";
                unit.unitID = unitID++;
            }

            allUnits.Add(unit);
            spawnOffset.z -= 1f;
        }

        // Spawn Catapults
        spawnOffset = new Vector3(-4, 0, 0);
        for (int i = 0; i < currentWave.catapultCount; i++)
        {
            GameObject unitObj = Instantiate(catapultPrefab, unitStagingArea + spawnOffset, Quaternion.identity);
            unitObj.name = $"Catapult_{i + 1}";

            DefensiveUnit unit = unitObj.GetComponent<DefensiveUnit>();
            if (unit != null)
            {
                unit.unitType = DefensiveUnit.UnitType.Catapult;
                unit.unitName = $"Catapult-{unitID}";
                unit.unitID = unitID++;
            }

            allUnits.Add(unit);
            spawnOffset.z -= 1f;
        }

        // Assign to CSP Solver
        if (cspSolver != null)
        {
            cspSolver.availableUnits = allUnits;
        }

        Debug.Log($"Spawned {allUnits.Count} units for Wave {currentWave.waveNumber}");
    }

    /// <summary>
    /// Start enemy attack phase (after CSP solving completes)
    /// </summary>
    public void StartEnemyAttack()
    {
        if (enemiesSpawned)
        {
            Debug.LogWarning("Enemies already spawned for this wave");
            return;
        }

        Debug.Log($"----------------------------------------");
        Debug.Log($"  ENEMY ATTACK COMMENCING");
        Debug.Log($"  Wave {currentWave.waveNumber}: {currentWave.enemyAttacks.Count} attack groups");
        Debug.Log($"----------------------------------------");

        StartCoroutine(SpawnEnemiesCoroutine());
    }

    /// <summary>
    /// Spawn enemies with delays based on arrival times
    /// </summary>
    IEnumerator SpawnEnemiesCoroutine()
    {
        enemiesSpawned = true;
        waveActive = true;

        foreach (var attack in currentWave.enemyAttacks)
        {
            // Wait until scheduled arrival time
            yield return new WaitForSeconds(attack.arrivalTime);

            // Find target position
            DefensePosition targetPos = cspSolver.positions.Find(p => p.positionName == attack.targetPositionName);
            if (targetPos == null)
            {
                Debug.LogWarning($"Target position not found: {attack.targetPositionName}");
                continue;
            }

            // Spawn enemy group
            Vector3 spawnPos = targetPos.transform.position + attack.spawnOffset;

            for (int i = 0; i < attack.enemyCount; i++)
            {
                GameObject enemyObj = Instantiate(enemyPrefab, spawnPos + Vector3.right * i * 0.5f, Quaternion.identity);
                Enemy enemy = enemyObj.GetComponent<Enemy>();

                if (enemy != null)
                {
                    enemy.Initialize(attack.enemyType, targetPos, spawnPos);
                    enemy.StartAttack();
                    activeEnemies.Add(enemy);
                }
            }

            Debug.Log($"[Wave] Spawned {attack.enemyCount} {attack.enemyType} attacking {attack.targetPositionName}");
        }

        // Wait for all enemies to resolve
        yield return new WaitForSeconds(5f);
        CheckWaveCompletion();
    }

    /// <summary>
    /// Check if wave is complete (all enemies defeated or breached)
    /// </summary>
    void CheckWaveCompletion()
    {
        int totalEnemies = 0;
        foreach (var attack in currentWave.enemyAttacks)
        {
            totalEnemies += attack.enemyCount;
        }

        // Count defeated and breached enemies
        enemiesDefeated = 0;
        enemiesBreached = 0;

        foreach (var enemy in activeEnemies)
        {
            if (enemy == null) // Destroyed = defeated
            {
                enemiesDefeated++;
            }
            // Check if breached (still exists, reached target, no defender)
        }

        Debug.Log($"Wave Complete: {enemiesDefeated} defeated, {enemiesBreached} breached");

        bool victory = (enemiesBreached == 0);

        if (gameManager != null)
        {
            if (victory)
            {
                gameManager.OnWaveComplete(true);
            }
            else
            {
                gameManager.OnWaveComplete(false);
            }
        }

        waveActive = false;
    }

    /// <summary>
    /// Advance to next wave
    /// </summary>
    public void NextWave()
    {
        if (currentWaveIndex + 1 < allWaves.Count)
        {
            LoadWave(currentWaveIndex + 1);
        }
        else
        {
            Debug.Log("-----------------------------------");
            Debug.Log("  ALL WAVES COMPLETE!");
            Debug.Log("  FORTRESS SUCCESSFULLY DEFENDED!");
            Debug.Log("-----------------------------------");

            if (gameManager != null)
            {
                gameManager.OnAllWavesComplete();
            }
        }
    }

    /// <summary>
    /// Restart current wave
    /// </summary>
    /// <summary>
    /// Restart current wave (used after recruitment - keeps modified unit counts)
    /// </summary>
    public void RestartWave()
    {
        Debug.Log("[WaveManager] Restarting wave WITHOUT resetting unit counts");

        // Clear enemies and units but DON'T reset unit counts
        ClearEnemies();
        ClearUnits();

        if (castleGenerator != null)
        {
            castleGenerator.ClearCurrentCastle();
        }

        // Now reload wave with current (modified) unit counts
        // Generate castle layout
        if (castleGenerator != null)
        {
            List<DefensePosition> positions = castleGenerator.GenerateCastle(currentWave);

            if (cspSolver != null)
            {
                cspSolver.positions = positions;
            }
        }

        // Spawn units with NEW counts
        SpawnUnits();

        // Update UI
        if (uiManager != null)
        {
            uiManager.UpdateWaveInfo(currentWave.waveNumber, allWaves.Count, currentWave.waveName);
            uiManager.UpdateStatus("Ready - Press SOLVE to start CSP algorithm");
        }

        // Set game state to Planning
        if (gameManager != null)
        {
            gameManager.SetGameState(GameManager.GameState.Planning);
        }

        Debug.Log($"[WaveManager] Wave restarted with {currentWave.archerCount} Archers, {currentWave.knightCount} Knights, {currentWave.catapultCount} Catapults");
    }

    /// <summary>
    /// Clear all enemies
    /// </summary>
    void ClearEnemies()
    {
        foreach (Enemy enemy in activeEnemies)
        {
            if (enemy != null)
            {
                Destroy(enemy.gameObject);
            }
        }
        activeEnemies.Clear();
    }

    /// <summary>
    /// Clear all units
    /// </summary>
    void ClearUnits()
    {
        foreach (DefensiveUnit unit in allUnits)
        {
            if (unit != null)
            {
                Destroy(unit.gameObject);
            }
        }
        allUnits.Clear();
    }

    /// <summary>
    /// Clear current wave
    /// </summary>
    void ClearWave()
    {
        // Reset current wave to original values before clearing
        if (currentWave != null)
        {
            currentWave.ResetToOriginalCounts();
        }

        ClearEnemies();
        ClearUnits();

        if (castleGenerator != null)
        {
            castleGenerator.ClearCurrentCastle();
        }
    }

    /// <summary>
    /// Get current wave configuration
    /// </summary>
    public WaveConfiguration GetCurrentWave()
    {
        return currentWave;
    }

    /// <summary>
    /// Get total number of waves
    /// </summary>
    public int GetTotalWaves()
    {
        return allWaves.Count;
    }

    /// <summary>
    /// Cleanup when stopping play mode or closing game
    /// </summary>
    void OnDestroy()
    {
        ResetAllWaveConfigurations();
    }

    /// <summary>
    /// Cleanup when application quits or play mode stops
    /// </summary>
    void OnApplicationQuit()
    {
        ResetAllWaveConfigurations();
    }

    /// <summary>
    /// Reset all wave configurations to their original values
    /// </summary>
    void ResetAllWaveConfigurations()
    {
        Debug.Log("[WaveManager] Resetting all wave configurations to original values");
        foreach (WaveConfiguration wave in allWaves)
        {
            if (wave != null)
            {
                wave.ResetToOriginalCounts();
            }
        }
    }
}