using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// Manages all UI elements for Fortress Defense CSP visualization
/// Displays status, statistics, and position/unit information
/// </summary>
public class UIManager : MonoBehaviour
{
    [Header("UI Text Elements")]
    public Text statusText;
    public Text backtrackCountText;
    public Text nodesExploredText;
    public Text waveInfoText;
    public Text positionStatesText;
    public Text availableUnitsText;

    [Header("Buttons")]
    public Button solveButton;
    public Button resetButton;
    public Button stepButton;  // Optional: step through solution one assignment at a time
    public Button nextWaveButton;  // NEW: Go to next wave
    public Button clearWaveButton;  // NEW: Clear/restart current wave

    [Header("Panels")]
    public GameObject solutionPanel;  // Shows when solution found
    public GameObject noSolutionPanel;  // Shows when no solution exists
    public GameObject recruitmentPanel;  // Shows recruitment options
    public UnityEngine.UI.Text recruitmentText;  // Text in recruitment panel
    public UnityEngine.UI.Button recruitButton;  // Recruit button

    [Header("References")]
    public GameManager gameManager;
    public RecruitmentSystem recruitmentSystem;

    void Start()
    {
        // Setup button listeners
        if (solveButton != null)
        {
            solveButton.onClick.AddListener(OnSolveButtonClicked);
        }

        if (resetButton != null)
        {
            resetButton.onClick.AddListener(OnResetButtonClicked);
        }

        if (stepButton != null)
        {
            stepButton.onClick.AddListener(OnStepButtonClicked);
            stepButton.gameObject.SetActive(false);  // Disabled for initial version
        }

        if (recruitButton != null)
        {
            recruitButton.onClick.AddListener(OnRecruitButtonClicked);
        }

        if (nextWaveButton != null)
        {
            nextWaveButton.onClick.AddListener(OnNextWaveButtonClicked);
            nextWaveButton.gameObject.SetActive(false);  // Hidden until solution found
        }

        if (clearWaveButton != null)
        {
            clearWaveButton.onClick.AddListener(OnClearWaveButtonClicked);
        }

        // Hide result panels initially
        if (solutionPanel != null) solutionPanel.SetActive(false);
        if (noSolutionPanel != null) noSolutionPanel.SetActive(false);
        if (recruitmentPanel != null) recruitmentPanel.SetActive(false);

        UpdateStatus("Initializing...");
        UpdateBacktrackCount(0);
        UpdateNodesExplored(0);
    }

    /// <summary>
    /// Update main status text
    /// </summary>
    public void UpdateStatus(string message)
    {
        if (statusText != null)
        {
            statusText.text = $"STATUS: {message}";
        }
        Debug.Log($"[UI] Status: {message}");
    }

    /// <summary>
    /// Update backtrack counter
    /// </summary>
    public void UpdateBacktrackCount(int count)
    {
        if (backtrackCountText != null)
        {
            backtrackCountText.text = $"BACKTRACKS: {count}";
        }
    }

    /// <summary>
    /// Update nodes explored counter
    /// </summary>
    public void UpdateNodesExplored(int count)
    {
        if (nodesExploredText != null)
        {
            nodesExploredText.text = $"NODES EXPLORED: {count}";
        }
    }

    /// <summary>
    /// Update wave information display
    /// </summary>
    public void UpdateWaveInfo(int current, int total)
    {
        if (waveInfoText != null)
        {
            waveInfoText.text = $"WAVE {current} / {total}";
        }
    }

    /// <summary>
    /// Update wave information with name
    /// </summary>
    public void UpdateWaveInfo(int current, int total, string waveName)
    {
        if (waveInfoText != null)
        {
            waveInfoText.text = $"WAVE {current} / {total}\n{waveName}";
        }
    }

    /// <summary>
    /// Update display of all position states
    /// Shows which positions are assigned, being evaluated, or waiting
    /// </summary>
    public void UpdatePositionStates(List<DefensePosition> positions)
    {
        if (positionStatesText == null) return;

        string display = "POSITIONS:\n\n";

        foreach (DefensePosition position in positions)
        {
            string status;
            string icon;

            if (position.IsAssigned())
            {
                icon = "✓";
                status = $"{position.positionName}: {position.assignedUnit.GetDisplayName()}";
            }
            else if (position.GetDomainSize() == 0)
            {
                icon = "⚠️";
                status = $"{position.positionName}: WIPEOUT (no units available)";
            }
            else
            {
                icon = "○";
                status = $"{position.positionName}: Open (Domain: {position.GetDomainSize()})";
            }

            display += $"{icon} {status}\n";
        }

        positionStatesText.text = display;
    }

    /// <summary>
    /// Update display of available units
    /// </summary>
    public void UpdateAvailableUnits(List<DefensiveUnit> units)
    {
        if (availableUnitsText == null) return;

        string display = "AVAILABLE UNITS:\n\n";

        foreach (DefensiveUnit unit in units)
        {
            string icon = unit.GetIcon();
            string status;

            if (unit.IsAssigned())
            {
                status = $"{unit.GetDisplayName()}: PLACED at {unit.assignedPosition.positionName}";
            }
            else
            {
                // Count how many positions this unit can still go to
                // (Would need reference to positions for accurate count)
                status = $"{unit.GetDisplayName()}: Available";
            }

            display += $"{icon} {status}\n";
        }

        availableUnitsText.text = display;
    }

    /// <summary>
    /// Show solution found message
    /// </summary>
    public void ShowSolutionFoundMessage()
    {
        UpdateStatus("✓ SOLUTION FOUND!");

        if (solutionPanel != null)
        {
            solutionPanel.SetActive(true);
        }

        if (noSolutionPanel != null)
        {
            noSolutionPanel.SetActive(false);
        }

        // Show Next Wave button
        if (nextWaveButton != null)
        {
            nextWaveButton.gameObject.SetActive(true);
        }
    }

    /// <summary>
    /// Show no solution message and offer recruitment
    /// </summary>
    public void ShowNoSolutionMessage()
    {
        Debug.Log("[UIManager] ShowNoSolutionMessage called");
        UpdateStatus("✗ NO SOLUTION EXISTS - Recruitment Available");

        if (noSolutionPanel != null)
        {
            noSolutionPanel.SetActive(true);
            Debug.Log("[UIManager] No solution panel activated");
        }
        else
        {
            Debug.LogWarning("[UIManager] noSolutionPanel is NULL!");
        }

        if (solutionPanel != null)
        {
            solutionPanel.SetActive(false);
        }

        // Analyze failure and show recruitment panel
        if (recruitmentSystem != null)
        {
            Debug.Log("[UIManager] RecruitmentSystem found, analyzing failure...");
            recruitmentSystem.AnalyzeFailure();

            // Get the needed units and cost
            Dictionary<DefensiveUnit.UnitType, int> neededUnits = recruitmentSystem.GetNeededUnits();
            int cost = recruitmentSystem.GetRecruitmentCost();

            Debug.Log($"[UIManager] Needed units count: {neededUnits.Count}, Cost: {cost}");
            ShowRecruitmentPanel(neededUnits, cost);
        }
        else
        {
            Debug.LogError("[UIManager] RecruitmentSystem is NULL! Cannot show recruitment panel.");
            Debug.LogError("[UIManager] Please assign RecruitmentSystem in UIManager Inspector!");
        }
    }

    /// <summary>
    /// Hide result panels
    /// </summary>
    void HideResultPanels()
    {
        if (solutionPanel != null) solutionPanel.SetActive(false);
        if (noSolutionPanel != null) noSolutionPanel.SetActive(false);
        if (recruitmentPanel != null) recruitmentPanel.SetActive(false);
    }

    /// <summary>
    /// Handle Solve button click
    /// </summary>
    void OnSolveButtonClicked()
    {
        Debug.Log("[UI] Solve button clicked");
        HideResultPanels();

        if (gameManager != null)
        {
            gameManager.StartSolving();
        }
        else
        {
            Debug.LogError("GameManager reference not set in UIManager!");
        }

        // Disable solve button while solving
        if (solveButton != null)
        {
            solveButton.interactable = false;
        }
    }

    /// <summary>
    /// Handle Reset button click
    /// </summary>
    void OnResetButtonClicked()
    {
        Debug.Log("[UI] Reset button clicked");
        HideResultPanels();

        if (gameManager != null)
        {
            gameManager.ResetWave();
        }

        // Re-enable solve button
        if (solveButton != null)
        {
            solveButton.interactable = true;
        }
    }

    /// <summary>
    /// Handle Step button click (future feature)
    /// </summary>
    void OnStepButtonClicked()
    {
        Debug.Log("[UI] Step button clicked (not implemented)");
        // Future: step through algorithm one assignment at a time
    }

    /// <summary>
    /// Handle Recruit button click
    /// </summary>
    void OnRecruitButtonClicked()
    {
        Debug.Log("[UI] Recruit button clicked");

        if (recruitmentSystem != null)
        {
            recruitmentSystem.ExecuteRecruitment();

            // Hide both recruitment and no solution panels
            HideRecruitmentPanel();
            HideNoSolutionPanel();

            // Update status
            UpdateStatus("Units recruited - Wave restarting...");
        }
        else
        {
            Debug.LogError("RecruitmentSystem reference not set in UIManager!");
        }
    }

    /// <summary>
    /// Handle Next Wave button click
    /// </summary>
    void OnNextWaveButtonClicked()
    {
        Debug.Log("[UI] Next Wave button clicked");

        if (gameManager != null)
        {
            gameManager.AdvanceToNextWave();

            // Hide solution panel
            if (solutionPanel != null)
            {
                solutionPanel.SetActive(false);
            }

            // Hide next wave button
            if (nextWaveButton != null)
            {
                nextWaveButton.gameObject.SetActive(false);
            }
        }
    }

    /// <summary>
    /// Handle Clear Wave button click
    /// </summary>
    void OnClearWaveButtonClicked()
    {
        Debug.Log("[UI] Clear Wave button clicked");

        if (gameManager != null)
        {
            // Hide all panels
            if (solutionPanel != null) solutionPanel.SetActive(false);
            if (noSolutionPanel != null) noSolutionPanel.SetActive(false);
            if (recruitmentPanel != null) recruitmentPanel.SetActive(false);

            // Restart the wave
            gameManager.RestartCurrentWave();
        }
    }

    /// <summary>
    /// Show recruitment panel with needed units
    /// </summary>
    public void ShowRecruitmentPanel(Dictionary<DefensiveUnit.UnitType, int> neededUnits, int totalCost)
    {
        Debug.Log("[UIManager] ShowRecruitmentPanel called");
        Debug.Log($"[UIManager] neededUnits count: {neededUnits?.Count ?? 0}");
        Debug.Log($"[UIManager] totalCost: {totalCost}");

        if (recruitmentPanel != null)
        {
            recruitmentPanel.SetActive(true);
            Debug.Log("[UIManager] ✓ Recruitment panel activated!");
        }
        else
        {
            Debug.LogError("[UIManager] ✗ recruitmentPanel is NULL!");
            return;
        }

        if (recruitmentText != null)
        {
            string text = "⚠️ NO SOLUTION EXISTS ⚠️\n\n";
            text += "Not enough units to defend all positions!\n\n";
            text += "RECRUITMENT NEEDED:\n\n";

            foreach (var kvp in neededUnits)
            {
                string icon = "";
                int cost = 0;
                switch (kvp.Key)
                {
                    case DefensiveUnit.UnitType.Archer:
                        icon = "🏹";
                        cost = 50;
                        break;
                    case DefensiveUnit.UnitType.Knight:
                        icon = "⚔️";
                        cost = 75;
                        break;
                    case DefensiveUnit.UnitType.Catapult:
                        icon = "🎯";
                        cost = 100;
                        break;
                }

                text += $"{icon} {kvp.Value} {kvp.Key}(s) - {kvp.Value * cost} gold\n";
            }

            text += $"\n💰 TOTAL COST: {totalCost} gold\n\n";
            text += "Click RECRUIT to hire these units!";

            recruitmentText.text = text;
        }

        Debug.Log("[UI] Recruitment panel displayed");
    }

    /// <summary>
    /// Hide recruitment panel
    /// </summary>
    public void HideRecruitmentPanel()
    {
        if (recruitmentPanel != null)
        {
            recruitmentPanel.SetActive(false);
        }
    }

    /// <summary>
    /// Hide no solution panel
    /// </summary>
    public void HideNoSolutionPanel()
    {
        if (noSolutionPanel != null)
        {
            noSolutionPanel.SetActive(false);
        }
    }

    /// <summary>
    /// Called when game state changes
    /// </summary>
    public void OnGameStateChanged(GameManager.GameState newState)
    {
        // Update button states based on game state
        switch (newState)
        {
            case GameManager.GameState.Setup:
                if (solveButton != null) solveButton.interactable = false;
                if (resetButton != null) resetButton.interactable = false;
                break;

            case GameManager.GameState.Planning:
                if (solveButton != null) solveButton.interactable = true;
                if (resetButton != null) resetButton.interactable = true;
                break;

            case GameManager.GameState.Solving:
                if (solveButton != null) solveButton.interactable = false;
                if (resetButton != null) resetButton.interactable = false;
                break;

            case GameManager.GameState.Solved:
                if (solveButton != null) solveButton.interactable = false;
                if (resetButton != null) resetButton.interactable = true;
                break;
        }
    }
}