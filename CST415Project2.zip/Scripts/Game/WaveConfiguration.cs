using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// ScriptableObject that defines a wave/level configuration
/// Each wave has unique castle layout, available units, and enemy threats
/// </summary>
[CreateAssetMenu(fileName = "Wave_", menuName = "Fortress Defense/Wave Configuration", order = 1)]
public class WaveConfiguration : ScriptableObject
{
    [Header("Wave Info")]
    public int waveNumber = 1;
    public string waveName = "Wave 1";
    [TextArea(3, 5)]
    public string waveDescription = "Tutorial wave";
    public WaveDifficulty difficulty = WaveDifficulty.Easy;

    [Header("Castle Layout")]
    public CastleLayout castleLayout = CastleLayout.Standard;
    public List<PositionData> positions = new List<PositionData>();

    [Header("Available Units")]
    public int archerCount = 3;
    public int knightCount = 2;
    public int catapultCount = 1;

    // Store original values for reset (not serialized, runtime only)
    [System.NonSerialized]
    private int originalArcherCount = -1;
    [System.NonSerialized]
    private int originalKnightCount = -1;
    [System.NonSerialized]
    private int originalCatapultCount = -1;
    [System.NonSerialized]
    private bool hasStoredOriginals = false;

    /// <summary>
    /// Store the original unit counts (called when wave first loads)
    /// </summary>
    public void StoreOriginalCounts()
    {
        if (!hasStoredOriginals)
        {
            originalArcherCount = archerCount;
            originalKnightCount = knightCount;
            originalCatapultCount = catapultCount;
            hasStoredOriginals = true;
            Debug.Log($"[WaveConfig] Stored original counts: A={originalArcherCount}, K={originalKnightCount}, C={originalCatapultCount}");
        }
    }

    /// <summary>
    /// Reset unit counts to original values (called when stopping play mode or switching waves)
    /// </summary>
    public void ResetToOriginalCounts()
    {
        if (hasStoredOriginals)
        {
            Debug.Log($"[WaveConfig] Resetting from A={archerCount}, K={knightCount}, C={catapultCount}");
            archerCount = originalArcherCount;
            knightCount = originalKnightCount;
            catapultCount = originalCatapultCount;
            Debug.Log($"[WaveConfig] Reset to original: A={archerCount}, K={knightCount}, C={catapultCount}");
            hasStoredOriginals = false;
        }
    }

    [Header("Enemy Waves")]
    public List<EnemyAttack> enemyAttacks = new List<EnemyAttack>();

    [Header("Victory Conditions")]
    public bool allPositionsDefended = true;
    public float timeLimit = 120f;

    public enum WaveDifficulty
    {
        Easy,
        Medium,
        Hard,
        Expert
    }

    public enum CastleLayout
    {
        Standard,      // Square castle
        LShape,        // L-shaped fortress
        Circle,        // Circular fortress
        TShape,        // T-shaped fortress
        Star,          // Star fortress
        Cross          // Cross-shaped fortress
    }

    /// <summary>
    /// Data for a single defensive position in this wave
    /// </summary>
    [System.Serializable]
    public class PositionData
    {
        public string positionName;
        public DefensePosition.PositionType positionType;
        public Vector3 localPosition;
        public bool isUnderThreat;
        public float threatLevel;
    }

    /// <summary>
    /// Data for enemy attack on a position
    /// </summary>
    [System.Serializable]
    public class EnemyAttack
    {
        public string targetPositionName;
        public EnemyType enemyType;
        public int enemyCount;
        public float arrivalTime;
        public Vector3 spawnOffset;
    }

    public enum EnemyType
    {
        Infantry,
        Archer,
        Cavalry,
        SiegeTower,
        BatteringRam
    }

    /// <summary>
    /// Get total number of positions for this wave
    /// </summary>
    public int GetTotalPositions()
    {
        return positions.Count;
    }

    /// <summary>
    /// Get total number of available units
    /// </summary>
    public int GetTotalUnits()
    {
        return archerCount + knightCount + catapultCount;
    }

    /// <summary>
    /// Get number of threatened positions
    /// </summary>
    public int GetThreatenedPositionsCount()
    {
        return positions.FindAll(p => p.isUnderThreat).Count;
    }
}