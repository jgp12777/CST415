using UnityEngine;

/// <summary>
/// Main game state manager for Fortress Defense
/// Handles game flow, scene management, and coordination between systems
/// </summary>
public class GameManager : MonoBehaviour
{
    public enum GameState
    {
        Setup,      // Initial setup, loading wave
        Planning,   // Player can view scenario (optional manual placement)
        Solving,    // CSP solver running
        Solved,     // Solution found or no solution
        Complete    // Wave complete (for future expansion to combat phase)
    }

    [Header("References")]
    public CSPSolver cspSolver;
    public UIManager uiManager;
    public WaveManager waveManager;
    public RecruitmentSystem recruitmentSystem;

    [Header("Game State")]
    public GameState currentState = GameState.Setup;
    public int currentWave = 1;
    public int totalWaves = 1;

    void Start()
    {
        SetGameState(GameState.Setup);

        // Initialize WaveManager
        if (waveManager != null)
        {
            totalWaves = waveManager.GetTotalWaves();
            waveManager.Initialize();
        }
        else
        {
            Debug.LogError("WaveManager not assigned to GameManager!");
        }
    }

    /// <summary>
    /// Start CSP solving process
    /// </summary>
    public void StartSolving()
    {
        if (currentState != GameState.Planning && currentState != GameState.Solved)
        {
            Debug.LogWarning($"Cannot start solving from state: {currentState}");
            return;
        }

        SetGameState(GameState.Solving);

        if (cspSolver != null)
        {
            cspSolver.StartSolving();
        }
        else
        {
            Debug.LogError("CSPSolver reference not set in GameManager!");
        }
    }

    /// <summary>
    /// Called when CSP solver completes (success or failure)
    /// </summary>
    public void OnSolverComplete(bool success)
    {
        SetGameState(GameState.Solved);

        if (success)
        {
            Debug.Log("GameManager: Solver found solution");

            if (uiManager != null)
            {
                uiManager.ShowSolutionFoundMessage();
            }

            // Start combat phase after short delay
            Invoke(nameof(StartCombatPhase), 2f);
        }
        else
        {
            Debug.Log("GameManager: No solution exists");

            if (uiManager != null)
            {
                uiManager.ShowNoSolutionMessage();
            }

            // Analyze what units are needed
            if (recruitmentSystem != null)
            {
                recruitmentSystem.AnalyzeFailure();
            }
        }
    }

    /// <summary>
    /// Called when CSP solving completes successfully - start enemy attack
    /// </summary>
    public void StartCombatPhase()
    {
        SetGameState(GameState.Complete);

        if (uiManager != null)
        {
            uiManager.UpdateStatus("Combat Phase - Enemies Attacking!");
        }

        if (waveManager != null)
        {
            waveManager.StartEnemyAttack();
        }
    }

    /// <summary>
    /// Called when wave completes (all enemies defeated or breached)
    /// </summary>
    public void OnWaveComplete(bool victory)
    {
        if (victory)
        {
            Debug.Log("═══ WAVE VICTORY ═══");

            if (uiManager != null)
            {
                uiManager.UpdateStatus("Wave Defended Successfully!");
            }

            // Advance to next wave after delay
            Invoke(nameof(AdvanceToNextWave), 3f);
        }
        else
        {
            Debug.Log("═══ WAVE DEFEAT ═══");

            if (uiManager != null)
            {
                uiManager.UpdateStatus("Fortress Breached! Press RESET to retry.");
            }
        }
    }

    /// <summary>
    /// Advance to next wave
    /// </summary>
    public void AdvanceToNextWave()
    {
        if (waveManager != null)
        {
            waveManager.NextWave();
            SetGameState(GameState.Planning);
        }
    }

    /// <summary>
    /// Restart current wave (clear and reload)
    /// </summary>
    public void RestartCurrentWave()
    {
        Debug.Log("[GameManager] Restarting current wave");

        if (waveManager != null)
        {
            waveManager.RestartWave();
        }
    }

    /// <summary>
    /// Called when all waves are complete
    /// </summary>
    public void OnAllWavesComplete()
    {
        Debug.Log("═══════════════════════════════════");
        Debug.Log("  GAME COMPLETE - ALL WAVES DEFENDED!");
        Debug.Log("═══════════════════════════════════");

        if (uiManager != null)
        {
            uiManager.UpdateStatus("VICTORY! All waves defended!");
        }
    }

    /// <summary>
    /// Reset current wave to initial state
    /// </summary>
    public void ResetWave()
    {
        Debug.Log("Resetting wave...");

        if (waveManager != null)
        {
            waveManager.RestartWave();
        }

        SetGameState(GameState.Planning);

        if (uiManager != null)
        {
            uiManager.UpdateStatus("Reset - Ready to solve");
        }
    }

    /// <summary>
    /// Set game state and notify systems
    /// </summary>
    public void SetGameState(GameState newState)
    {
        GameState previousState = currentState;
        currentState = newState;

        Debug.Log($"State: {previousState} → {newState}");

        // Update UI based on state
        if (uiManager != null)
        {
            uiManager.OnGameStateChanged(currentState);
        }

        // State-specific actions
        switch (newState)
        {
            case GameState.Setup:
                break;

            case GameState.Planning:
                if (uiManager != null)
                {
                    uiManager.UpdateStatus("Ready - Press SOLVE to start CSP algorithm");
                }
                break;

            case GameState.Solving:
                if (uiManager != null)
                {
                    uiManager.UpdateStatus("CSP Solver Running...");
                }
                break;

            case GameState.Solved:
                // Handled by OnSolverComplete
                break;

            case GameState.Complete:
                // Combat phase
                break;
        }
    }

    /// <summary>
    /// Get current game state
    /// </summary>
    public GameState GetGameState()
    {
        return currentState;
    }

    /// <summary>
    /// Quit application or return to main menu
    /// </summary>
    public void QuitGame()
    {
        Debug.Log("Quitting game...");

#if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
#else
        Application.Quit();
#endif
    }
}