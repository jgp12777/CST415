using System.Collections.Generic;
using System.Linq;
using UnityEngine;

/// <summary>
/// Analyzes unsolvable CSP problems and determines what units need to be recruited
/// Provides solutions when the current unit roster is insufficient
/// </summary>
public class RecruitmentSystem : MonoBehaviour
{
    [Header("References")]
    public WaveManager waveManager;
    public CSPSolver cspSolver;
    public UIManager uiManager;

    [Header("Recruitment Analysis")]
    private Dictionary<DefensiveUnit.UnitType, int> neededUnits = new Dictionary<DefensiveUnit.UnitType, int>();
    private bool hasAnalyzedFailure = false;

    /// <summary>
    /// Analyze why CSP failed and determine what units are needed
    /// Uses intelligent algorithm to find MINIMAL set of units that will solve the CSP
    /// </summary>
    public void AnalyzeFailure()
    {
        hasAnalyzedFailure = true;
        neededUnits.Clear();

        Debug.Log("---------------------------------------");
        Debug.Log("  ANALYZING CSP FAILURE - FINDING MINIMAL SOLUTION");
        Debug.Log("---------------------------------------");

        // Get all positions and their requirements
        List<DefensePosition> positions = cspSolver.positions;
        List<DefensiveUnit> availableUnits = cspSolver.availableUnits;

        // Count current units
        Dictionary<DefensiveUnit.UnitType, int> currentUnits = new Dictionary<DefensiveUnit.UnitType, int>();
        currentUnits[DefensiveUnit.UnitType.Archer] = availableUnits.Count(u => u.unitType == DefensiveUnit.UnitType.Archer);
        currentUnits[DefensiveUnit.UnitType.Knight] = availableUnits.Count(u => u.unitType == DefensiveUnit.UnitType.Knight);
        currentUnits[DefensiveUnit.UnitType.Catapult] = availableUnits.Count(u => u.unitType == DefensiveUnit.UnitType.Catapult);

        Debug.Log("Current Units:");
        Debug.Log($"  Archers: {currentUnits[DefensiveUnit.UnitType.Archer]}");
        Debug.Log($"  Knights: {currentUnits[DefensiveUnit.UnitType.Knight]}");
        Debug.Log($"  Catapults: {currentUnits[DefensiveUnit.UnitType.Catapult]}");

        // Count REQUIRED units by analyzing position requirements and constraints
        // This creates a "perfect solution" by analyzing each position's compatible unit types
        Dictionary<DefensiveUnit.UnitType, int> requiredUnits = new Dictionary<DefensiveUnit.UnitType, int>();
        requiredUnits[DefensiveUnit.UnitType.Archer] = 0;
        requiredUnits[DefensiveUnit.UnitType.Knight] = 0;
        requiredUnits[DefensiveUnit.UnitType.Catapult] = 0;

        // Count positions by their REQUIRED unit type (based on constraints)
        int towerWallCount = 0;  // Need Archers
        int gateCount = 0;       // Need Knights  
        int outsideCount = 0;    // Need Catapults

        foreach (DefensePosition pos in positions)
        {
            // Only count threatened positions that need defending
            if (!pos.isUnderThreat) continue;

            switch (pos.positionType)
            {
                case DefensePosition.PositionType.Tower:
                case DefensePosition.PositionType.Wall:
                    towerWallCount++;
                    break;
                case DefensePosition.PositionType.Gate:
                    gateCount++;
                    break;
                case DefensePosition.PositionType.OutsideWalls:
                    outsideCount++;
                    break;
            }
        }

        // Now calculate MINIMUM units needed for a valid solution
        // This is the theoretical minimum based on position types
        requiredUnits[DefensiveUnit.UnitType.Archer] = towerWallCount;
        requiredUnits[DefensiveUnit.UnitType.Knight] = gateCount;
        requiredUnits[DefensiveUnit.UnitType.Catapult] = outsideCount;

        Debug.Log("Positions requiring defense:");
        Debug.Log($"  Towers/Walls (need Archers): {towerWallCount}");
        Debug.Log($"  Gates (need Knights): {gateCount}");
        Debug.Log($"  Outside Walls (need Catapults): {outsideCount}");

        Debug.Log("Minimum Required Units for Solution:");
        Debug.Log($"  Archers: {requiredUnits[DefensiveUnit.UnitType.Archer]}");
        Debug.Log($"  Knights: {requiredUnits[DefensiveUnit.UnitType.Knight]}");
        Debug.Log($"  Catapults: {requiredUnits[DefensiveUnit.UnitType.Catapult]}");

        // Calculate EXACT shortage
        int archerShortage = Mathf.Max(0, requiredUnits[DefensiveUnit.UnitType.Archer] - currentUnits[DefensiveUnit.UnitType.Archer]);
        int knightShortage = Mathf.Max(0, requiredUnits[DefensiveUnit.UnitType.Knight] - currentUnits[DefensiveUnit.UnitType.Knight]);
        int catapultShortage = Mathf.Max(0, requiredUnits[DefensiveUnit.UnitType.Catapult] - currentUnits[DefensiveUnit.UnitType.Catapult]);

        // Store shortages
        if (archerShortage > 0)
        {
            neededUnits[DefensiveUnit.UnitType.Archer] = archerShortage;
            Debug.Log($"  ! SHORTAGE: Need {archerShortage} more Archer(s)");
        }
        if (knightShortage > 0)
        {
            neededUnits[DefensiveUnit.UnitType.Knight] = knightShortage;
            Debug.Log($"  ! SHORTAGE: Need {knightShortage} more Knight(s)");
        }
        if (catapultShortage > 0)
        {
            neededUnits[DefensiveUnit.UnitType.Catapult] = catapultShortage;
            Debug.Log($"  ! SHORTAGE: Need {catapultShortage} more Catapult(s)");
        }

        // Edge case: if no shortage detected but CSP still failed, add a buffer
        if (neededUnits.Count == 0)
        {
            Debug.LogWarning("  ! No clear shortage detected - CSP may have failed due to complex constraints");
            Debug.LogWarning("  Adding 1 unit of each type as fallback");
            neededUnits[DefensiveUnit.UnitType.Archer] = 1;
            neededUnits[DefensiveUnit.UnitType.Knight] = 1;
            neededUnits[DefensiveUnit.UnitType.Catapult] = 1;
        }

        Debug.Log("\n RECRUITMENT SOLUTION:");
        foreach (var kvp in neededUnits)
        {
            Debug.Log($"  + {kvp.Value}� {kvp.Key}");
        }
        Debug.Log("---------------------------------------");
    }

    /// <summary>
    /// Get the recruitment recommendation as a formatted string
    /// </summary>
    public string GetRecruitmentMessage()
    {
        if (!hasAnalyzedFailure || neededUnits.Count == 0)
        {
            return "Recruitment analysis needed";
        }

        string message = "RECRUITMENT NEEDED:\n\n";

        foreach (var kvp in neededUnits)
        {
            string icon = GetUnitIcon(kvp.Key);
            message += $"{icon} {kvp.Value}� {kvp.Key}\n";
        }

        message += "\nClick RECRUIT to add these units";

        return message;
    }

    /// <summary>
    /// Get total recruitment cost (for future expansion)
    /// </summary>
    public int GetRecruitmentCost()
    {
        int totalCost = 0;

        foreach (var kvp in neededUnits)
        {
            int costPerUnit = GetUnitCost(kvp.Key);
            totalCost += costPerUnit * kvp.Value;
        }

        return totalCost;
    }

    /// <summary>
    /// Execute recruitment - add the needed units
    /// </summary>
    public void ExecuteRecruitment()
    {
        if (!hasAnalyzedFailure)
        {
            Debug.LogWarning("Cannot recruit - no analysis done yet");
            return;
        }

        if (neededUnits.Count == 0)
        {
            Debug.LogWarning("Cannot recruit - no units needed");
            return;
        }

        Debug.Log("---------------------------------------");
        Debug.Log("  EXECUTING RECRUITMENT");
        Debug.Log("---------------------------------------");

        if (waveManager != null)
        {
            WaveConfiguration currentWave = waveManager.GetCurrentWave();

            // Store the units we're adding for logging
            Dictionary<DefensiveUnit.UnitType, int> unitsToAdd = new Dictionary<DefensiveUnit.UnitType, int>(neededUnits);

            // Add the needed units to wave configuration
            foreach (var kvp in unitsToAdd)
            {
                switch (kvp.Key)
                {
                    case DefensiveUnit.UnitType.Archer:
                        currentWave.archerCount += kvp.Value;
                        Debug.Log($" Recruited {kvp.Value} Archers (total now: {currentWave.archerCount})");
                        break;
                    case DefensiveUnit.UnitType.Knight:
                        currentWave.knightCount += kvp.Value;
                        Debug.Log($" Recruited {kvp.Value} Knights (total now: {currentWave.knightCount})");
                        break;
                    case DefensiveUnit.UnitType.Catapult:
                        currentWave.catapultCount += kvp.Value;
                        Debug.Log($" Recruited {kvp.Value} Catapults (total now: {currentWave.catapultCount})");
                        break;
                }
            }

            Debug.Log("---------------------------------------");

            // Reset analysis BEFORE restarting wave (important!)
            hasAnalyzedFailure = false;
            neededUnits.Clear();

            // Restart wave with new units
            Debug.Log("Restarting wave with recruited units...");
            waveManager.RestartWave();
        }
        else
        {
            Debug.LogError("WaveManager reference is null!");
        }
    }

    /// <summary>
    /// Get icon for unit type
    /// </summary>
    string GetUnitIcon(DefensiveUnit.UnitType type)
    {
        switch (type)
        {
            case DefensiveUnit.UnitType.Archer: return "arc";
            case DefensiveUnit.UnitType.Knight: return "kni";
            case DefensiveUnit.UnitType.Catapult: return "ctp";
            default: return "?";
        }
    }

    /// <summary>
    /// Get cost per unit type (for future expansion with currency system)
    /// </summary>
    int GetUnitCost(DefensiveUnit.UnitType type)
    {
        switch (type)
        {
            case DefensiveUnit.UnitType.Archer: return 100;
            case DefensiveUnit.UnitType.Knight: return 150;
            case DefensiveUnit.UnitType.Catapult: return 200;
            default: return 100;
        }
    }

    /// <summary>
    /// Check if recruitment is needed
    /// </summary>
    public bool IsRecruitmentNeeded()
    {
        return hasAnalyzedFailure && neededUnits.Count > 0;
    }

    /// <summary>
    /// Get detailed breakdown for UI display
    /// </summary>
    public Dictionary<DefensiveUnit.UnitType, int> GetNeededUnits()
    {
        return new Dictionary<DefensiveUnit.UnitType, int>(neededUnits);
    }
}