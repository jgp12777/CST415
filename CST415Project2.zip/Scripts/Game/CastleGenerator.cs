using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Generates unique castle layouts for each wave
/// Creates walls, towers, gates, and outside positions based on layout type
/// </summary>
public class CastleGenerator : MonoBehaviour
{
    [Header("Prefabs")]
    public GameObject wallPrefab;
    public GameObject towerPrefab;
    public GameObject gatePrefab;
    public GameObject outsideWallPrefab;

    [Header("Materials")]
    public Material wallMaterial;
    public Material towerMaterial;
    public Material gateMaterial;
    public Material outsideWallsMaterial;

    [Header("Generation Settings")]
    public float tileSize = 2f;
    public float wallHeight = 2f;
    public float towerHeight = 3f;

    [Header("Current Castle")]
    private List<GameObject> currentCastleObjects = new List<GameObject>();
    public List<DefensePosition> generatedPositions = new List<DefensePosition>();

    /// <summary>
    /// Generate castle based on wave configuration
    /// </summary>
    public List<DefensePosition> GenerateCastle(WaveConfiguration waveConfig)
    {
        ClearCurrentCastle();

        switch (waveConfig.castleLayout)
        {
            case WaveConfiguration.CastleLayout.Standard:
                return GenerateStandardCastle(waveConfig);
            case WaveConfiguration.CastleLayout.LShape:
                return GenerateLShapeCastle(waveConfig);
            case WaveConfiguration.CastleLayout.Circle:
                return GenerateCircleCastle(waveConfig);
            case WaveConfiguration.CastleLayout.TShape:
                return GenerateTShapeCastle(waveConfig);
            case WaveConfiguration.CastleLayout.Star:
                return GenerateStarCastle(waveConfig);
            case WaveConfiguration.CastleLayout.Cross:
                return GenerateCrossCastle(waveConfig);
            default:
                return GenerateStandardCastle(waveConfig);
        }
    }

    /// <summary>
    /// Standard square castle with 4 corners and gates
    /// </summary>
    List<DefensePosition> GenerateStandardCastle(WaveConfiguration waveConfig)
    {
        generatedPositions.Clear();

        // Create 4 corner towers
        generatedPositions.Add(CreatePosition("North Tower", DefensePosition.PositionType.Tower,
            new Vector3(0, 0, 4), true, 10f));
        generatedPositions.Add(CreatePosition("East Tower", DefensePosition.PositionType.Tower,
            new Vector3(4, 0, 0), false, 5f));
        generatedPositions.Add(CreatePosition("South Tower", DefensePosition.PositionType.Tower,
            new Vector3(0, 0, -4), false, 5f));
        generatedPositions.Add(CreatePosition("West Tower", DefensePosition.PositionType.Tower,
            new Vector3(-4, 0, 0), false, 5f));

        // Create 2 gates
        generatedPositions.Add(CreatePosition("Main Gate", DefensePosition.PositionType.Gate,
            new Vector3(4, 0, 2), true, 15f));
        generatedPositions.Add(CreatePosition("Side Gate", DefensePosition.PositionType.Gate,
            new Vector3(-4, 0, -2), false, 8f));

        // Create 2 wall sections
        generatedPositions.Add(CreatePosition("North Wall", DefensePosition.PositionType.Wall,
            new Vector3(2, 0, 4), true, 8f));
        generatedPositions.Add(CreatePosition("South Wall", DefensePosition.PositionType.Wall,
            new Vector3(-2, 0, -4), false, 6f));

        // Create outside positions for catapults
        generatedPositions.Add(CreatePosition("Outside North", DefensePosition.PositionType.OutsideWalls,
            new Vector3(0, 0, 6), false, 3f));

        Debug.Log($"Generated Standard Castle: {generatedPositions.Count} positions");
        return generatedPositions;
    }

    /// <summary>
    /// L-shaped fortress with angled walls
    /// </summary>
    List<DefensePosition> GenerateLShapeCastle(WaveConfiguration waveConfig)
    {
        generatedPositions.Clear();

        // Corner towers forming L shape
        generatedPositions.Add(CreatePosition("Corner Tower", DefensePosition.PositionType.Tower,
            new Vector3(0, 0, 0), true, 12f));
        generatedPositions.Add(CreatePosition("North Tower", DefensePosition.PositionType.Tower,
            new Vector3(0, 0, 5), true, 10f));
        generatedPositions.Add(CreatePosition("East Tower", DefensePosition.PositionType.Tower,
            new Vector3(5, 0, 0), true, 10f));

        // Gates on exposed sides
        generatedPositions.Add(CreatePosition("North Gate", DefensePosition.PositionType.Gate,
            new Vector3(-1, 0, 5), true, 15f));
        generatedPositions.Add(CreatePosition("East Gate", DefensePosition.PositionType.Gate,
            new Vector3(5, 0, -1), true, 15f));

        // Wall sections
        generatedPositions.Add(CreatePosition("North Wall", DefensePosition.PositionType.Wall,
            new Vector3(0, 0, 3), false, 7f));
        generatedPositions.Add(CreatePosition("East Wall", DefensePosition.PositionType.Wall,
            new Vector3(3, 0, 0), false, 7f));

        // Outside positions
        generatedPositions.Add(CreatePosition("Outside Corner", DefensePosition.PositionType.OutsideWalls,
            new Vector3(6, 0, 6), false, 4f));
        generatedPositions.Add(CreatePosition("Outside North", DefensePosition.PositionType.OutsideWalls,
            new Vector3(-2, 0, 6), false, 4f));

        Debug.Log($"Generated L-Shape Castle: {generatedPositions.Count} positions");
        return generatedPositions;
    }

    /// <summary>
    /// Circular fortress with towers around perimeter
    /// </summary>
    List<DefensePosition> GenerateCircleCastle(WaveConfiguration waveConfig)
    {
        generatedPositions.Clear();
        float radius = 5f;

        // Create 6 towers around circle
        for (int i = 0; i < 6; i++)
        {
            float angle = i * 60f * Mathf.Deg2Rad;
            Vector3 pos = new Vector3(Mathf.Cos(angle) * radius, 0, Mathf.Sin(angle) * radius);
            bool threatened = (i % 2 == 0); // Every other tower threatened

            generatedPositions.Add(CreatePosition($"Tower {i + 1}", DefensePosition.PositionType.Tower,
                pos, threatened, threatened ? 10f : 5f));
        }

        // Create 3 gates between towers
        for (int i = 0; i < 3; i++)
        {
            float angle = (i * 120f + 30f) * Mathf.Deg2Rad;
            Vector3 pos = new Vector3(Mathf.Cos(angle) * radius, 0, Mathf.Sin(angle) * radius);
            bool threatened = (i == 0); // Only first gate threatened

            generatedPositions.Add(CreatePosition($"Gate {i + 1}", DefensePosition.PositionType.Gate,
                pos, threatened, threatened ? 15f : 8f));
        }

        // Outside positions
        generatedPositions.Add(CreatePosition("Outside North", DefensePosition.PositionType.OutsideWalls,
            new Vector3(0, 0, 7), false, 3f));
        generatedPositions.Add(CreatePosition("Outside South", DefensePosition.PositionType.OutsideWalls,
            new Vector3(0, 0, -7), false, 3f));

        Debug.Log($"Generated Circle Castle: {generatedPositions.Count} positions");
        return generatedPositions;
    }

    /// <summary>
    /// T-shaped fortress
    /// </summary>
    List<DefensePosition> GenerateTShapeCastle(WaveConfiguration waveConfig)
    {
        generatedPositions.Clear();

        // Top of T - horizontal line
        generatedPositions.Add(CreatePosition("West Tower", DefensePosition.PositionType.Tower,
            new Vector3(-4, 0, 3), true, 10f));
        generatedPositions.Add(CreatePosition("Center Tower", DefensePosition.PositionType.Tower,
            new Vector3(0, 0, 3), true, 12f));
        generatedPositions.Add(CreatePosition("East Tower", DefensePosition.PositionType.Tower,
            new Vector3(4, 0, 3), true, 10f));

        // Stem of T
        generatedPositions.Add(CreatePosition("Central Wall", DefensePosition.PositionType.Wall,
            new Vector3(0, 0, 0), false, 6f));
        generatedPositions.Add(CreatePosition("South Tower", DefensePosition.PositionType.Tower,
            new Vector3(0, 0, -3), false, 8f));

        // Gates
        generatedPositions.Add(CreatePosition("East Gate", DefensePosition.PositionType.Gate,
            new Vector3(5, 0, 3), true, 15f));
        generatedPositions.Add(CreatePosition("West Gate", DefensePosition.PositionType.Gate,
            new Vector3(-5, 0, 3), true, 15f));
        generatedPositions.Add(CreatePosition("South Gate", DefensePosition.PositionType.Gate,
            new Vector3(0, 0, -4), false, 10f));

        // Outside positions
        generatedPositions.Add(CreatePosition("Outside North", DefensePosition.PositionType.OutsideWalls,
            new Vector3(0, 0, 5), false, 4f));

        Debug.Log($"Generated T-Shape Castle: {generatedPositions.Count} positions");
        return generatedPositions;
    }

    /// <summary>
    /// Star-shaped fortress with 5 points
    /// </summary>
    List<DefensePosition> GenerateStarCastle(WaveConfiguration waveConfig)
    {
        generatedPositions.Clear();
        float outerRadius = 6f;
        float innerRadius = 3f;

        // Create 5 outer point towers
        for (int i = 0; i < 5; i++)
        {
            float angle = (i * 72f - 90f) * Mathf.Deg2Rad; // Start from top
            Vector3 pos = new Vector3(Mathf.Cos(angle) * outerRadius, 0, Mathf.Sin(angle) * outerRadius);

            generatedPositions.Add(CreatePosition($"Point Tower {i + 1}", DefensePosition.PositionType.Tower,
                pos, true, 12f));
        }

        // Create 5 inner walls between points
        for (int i = 0; i < 5; i++)
        {
            float angle = (i * 72f + 36f - 90f) * Mathf.Deg2Rad;
            Vector3 pos = new Vector3(Mathf.Cos(angle) * innerRadius, 0, Mathf.Sin(angle) * innerRadius);

            generatedPositions.Add(CreatePosition($"Wall {i + 1}", DefensePosition.PositionType.Wall,
                pos, false, 6f));
        }

        // Gates at 2 points
        generatedPositions.Add(CreatePosition("Main Gate", DefensePosition.PositionType.Gate,
            new Vector3(0, 0, -6), true, 18f));
        generatedPositions.Add(CreatePosition("Side Gate", DefensePosition.PositionType.Gate,
            new Vector3(5.5f, 0, -2), false, 10f));

        // Outside position
        generatedPositions.Add(CreatePosition("Outside Center", DefensePosition.PositionType.OutsideWalls,
            new Vector3(0, 0, 8), false, 4f));

        Debug.Log($"Generated Star Castle: {generatedPositions.Count} positions");
        return generatedPositions;
    }

    /// <summary>
    /// Cross-shaped fortress
    /// </summary>
    List<DefensePosition> GenerateCrossCastle(WaveConfiguration waveConfig)
    {
        generatedPositions.Clear();

        // Four arms of the cross
        generatedPositions.Add(CreatePosition("North Tower", DefensePosition.PositionType.Tower,
            new Vector3(0, 0, 5), true, 12f));
        generatedPositions.Add(CreatePosition("East Tower", DefensePosition.PositionType.Tower,
            new Vector3(5, 0, 0), true, 12f));
        generatedPositions.Add(CreatePosition("South Tower", DefensePosition.PositionType.Tower,
            new Vector3(0, 0, -5), true, 12f));
        generatedPositions.Add(CreatePosition("West Tower", DefensePosition.PositionType.Tower,
            new Vector3(-5, 0, 0), true, 12f));

        // Center point
        generatedPositions.Add(CreatePosition("Central Keep", DefensePosition.PositionType.Tower,
            new Vector3(0, 0, 0), true, 15f));

        // Gates at end of each arm
        generatedPositions.Add(CreatePosition("North Gate", DefensePosition.PositionType.Gate,
            new Vector3(0, 0, 6), true, 15f));
        generatedPositions.Add(CreatePosition("East Gate", DefensePosition.PositionType.Gate,
            new Vector3(6, 0, 0), true, 15f));
        generatedPositions.Add(CreatePosition("South Gate", DefensePosition.PositionType.Gate,
            new Vector3(0, 0, -6), true, 15f));
        generatedPositions.Add(CreatePosition("West Gate", DefensePosition.PositionType.Gate,
            new Vector3(-6, 0, 0), false, 10f));

        // Walls connecting arms
        generatedPositions.Add(CreatePosition("NE Wall", DefensePosition.PositionType.Wall,
            new Vector3(2.5f, 0, 2.5f), false, 6f));
        generatedPositions.Add(CreatePosition("SE Wall", DefensePosition.PositionType.Wall,
            new Vector3(2.5f, 0, -2.5f), false, 6f));

        // Outside positions
        generatedPositions.Add(CreatePosition("Outside North", DefensePosition.PositionType.OutsideWalls,
            new Vector3(0, 0, 8), false, 4f));
        generatedPositions.Add(CreatePosition("Outside East", DefensePosition.PositionType.OutsideWalls,
            new Vector3(8, 0, 0), false, 4f));

        Debug.Log($"Generated Cross Castle: {generatedPositions.Count} positions");
        return generatedPositions;
    }

    /// <summary>
    /// Helper to create a position with proper setup
    /// </summary>
    DefensePosition CreatePosition(string name, DefensePosition.PositionType type, Vector3 position, bool threatened, float threatLevel)
    {
        GameObject prefab = GetPrefabForType(type);
        if (prefab == null)
        {
            Debug.LogError($"No prefab found for position type: {type}");
            return null;
        }

        GameObject posObj = Instantiate(prefab, position, Quaternion.identity, transform);
        posObj.name = name;

        DefensePosition defPos = posObj.GetComponent<DefensePosition>();
        if (defPos == null)
        {
            defPos = posObj.AddComponent<DefensePosition>();
        }

        defPos.positionType = type;
        defPos.positionName = name;
        defPos.positionID = generatedPositions.Count + 1;
        defPos.isUnderThreat = threatened;
        defPos.threatLevel = threatLevel;

        // Add visualizer if not present
        if (posObj.GetComponent<PositionVisualizer>() == null)
        {
            posObj.AddComponent<PositionVisualizer>();
        }

        // Apply appropriate material
        Renderer renderer = posObj.GetComponent<Renderer>();
        if (renderer != null)
        {
            renderer.material = GetMaterialForType(type);
        }

        currentCastleObjects.Add(posObj);
        return defPos;
    }

    /// <summary>
    /// Get prefab based on position type
    /// </summary>
    GameObject GetPrefabForType(DefensePosition.PositionType type)
    {
        switch (type)
        {
            case DefensePosition.PositionType.Wall:
                return wallPrefab;
            case DefensePosition.PositionType.Tower:
                return towerPrefab;
            case DefensePosition.PositionType.Gate:
                return gatePrefab;
            case DefensePosition.PositionType.OutsideWalls:
                return outsideWallPrefab;
            default:
                return towerPrefab;
        }
    }

    /// <summary>
    /// Get material based on position type
    /// </summary>
    Material GetMaterialForType(DefensePosition.PositionType type)
    {
        switch (type)
        {
            case DefensePosition.PositionType.Wall:
                return wallMaterial;
            case DefensePosition.PositionType.Tower:
                return towerMaterial;
            case DefensePosition.PositionType.Gate:
                return gateMaterial;
            case DefensePosition.PositionType.OutsideWalls:
                return outsideWallsMaterial;
            default:
                return towerMaterial;
        }
    }

    /// <summary>
    /// Clear current castle objects
    /// </summary>
    public void ClearCurrentCastle()
    {
        foreach (GameObject obj in currentCastleObjects)
        {
            if (obj != null)
            {
                Destroy(obj);
            }
        }
        currentCastleObjects.Clear();
        generatedPositions.Clear();
    }

    /// <summary>
    /// Get all generated positions
    /// </summary>
    public List<DefensePosition> GetGeneratedPositions()
    {
        return new List<DefensePosition>(generatedPositions);
    }
}