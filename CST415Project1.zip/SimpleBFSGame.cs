using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class SimpleBFSGame : MonoBehaviour
{
    [Header("UI References")]
    public TextMeshProUGUI outputText;

    [Header("Animation Settings")]
    public float animationSpeed = 0.5f; // Seconds per step

    // HARDCODED 3x3 - DO NOT CHANGE!
    private const int GRID_SIZE = 3;
    private const int STARTING_FOOD = 50;

    // Game state
    private Vector2Int playerPos;
    private HashSet<Vector2Int> explored;
    private int food;
    private List<string> logMessages;
    private List<Vector2Int> optimalPath;
    private int playerMoves;

    // Animation state
    private bool isAnimating = false;
    private int animationStep = 0;
    private float animationTimer = 0f;
    private bool showAnimationStep = true; // For blinking effect

    void Start()
    {
        logMessages = new List<string>();
        StartNewGame();
    }

    void Update()
    {
        // Handle input only when not animating
        if (!isAnimating)
        {
            if (Input.GetKeyDown(KeyCode.W)) TryMove(Vector2Int.up);
            if (Input.GetKeyDown(KeyCode.S)) TryMove(Vector2Int.down);
            if (Input.GetKeyDown(KeyCode.A)) TryMove(Vector2Int.left);
            if (Input.GetKeyDown(KeyCode.D)) TryMove(Vector2Int.right);
            if (Input.GetKeyDown(KeyCode.Space)) RunBFS();
            if (Input.GetKeyDown(KeyCode.R)) StartNewGame();
            if (Input.GetKeyDown(KeyCode.V) && optimalPath != null) StartAnimation();
        }
        else
        {
            // Animation controls
            if (Input.GetKeyDown(KeyCode.Escape)) StopAnimation();
            if (Input.GetKeyDown(KeyCode.RightArrow)) AdvanceAnimation();
        }

        // Update animation
        if (isAnimating)
        {
            UpdateAnimation();
        }
    }

    void StartNewGame()
    {
        playerPos = Vector2Int.zero;
        explored = new HashSet<Vector2Int> { playerPos };
        food = STARTING_FOOD;
        playerMoves = 0;
        optimalPath = null;
        isAnimating = false;

        logMessages.Clear();
        Log("======================================");
        Log("  GRID EXPLORER BFS - 3x3 GRID");
        Log("======================================");
        Log($"Grid Size: {GRID_SIZE}x{GRID_SIZE} (9 tiles)");
        Log($"Starting Food: {food}");
        Log("");
        Log("Controls:");
        Log("  SPACE   - Run BFS");
        Log("  V       - Visualize Path (after BFS)");
        Log("  W/A/S/D - Move Manually");
        Log("  R       - Restart");
        Log("");
        Log("Press SPACE to find optimal path!");
        UpdateDisplay();
    }

    void TryMove(Vector2Int direction)
    {
        Vector2Int newPos = playerPos + direction;

        if (newPos.x < 0 || newPos.x >= GRID_SIZE || newPos.y < 0 || newPos.y >= GRID_SIZE)
        {
            Log("Cannot move out of bounds!");
            UpdateDisplay();
            return;
        }

        if (food < 2)
        {
            Log("OUT OF FOOD! Game Over!");
            UpdateDisplay();
            return;
        }

        playerPos = newPos;
        food -= 2;
        playerMoves++;
        explored.Add(newPos);

        string dirName = direction == Vector2Int.up ? "UP" :
                        direction == Vector2Int.down ? "DOWN" :
                        direction == Vector2Int.left ? "LEFT" : "RIGHT";

        Log($"Move {dirName} to {newPos} (Food: {food})");

        if (explored.Count == GRID_SIZE * GRID_SIZE)
        {
            Log("");
            Log("======================================");
            Log("         *** VICTORY! ***");
            Log("======================================");
            Log($"All 9 tiles explored!");
            Log($"Your moves: {playerMoves}");
            if (optimalPath != null)
            {
                int optimal = optimalPath.Count - 1;
                Log($"Optimal moves: {optimal}");
                float eff = (optimal / (float)playerMoves) * 100f;
                Log($"Efficiency: {eff:F1}%");
            }
        }

        UpdateDisplay();
    }

    void RunBFS()
    {
        Log("");
        Log("======================================");
        Log("  RUNNING BFS ON 3x3 GRID");
        Log("======================================");

        Queue<Node> queue = new Queue<Node>();
        Dictionary<string, bool> visited = new Dictionary<string, bool>();

        Node start = new Node();
        start.position = Vector2Int.zero;
        start.tilesVisited = new List<Vector2Int> { Vector2Int.zero };

        queue.Enqueue(start);
        visited[start.GetStateKey()] = true;

        int statesChecked = 0;
        Node solution = null;

        Log("Starting BFS search...");

        while (queue.Count > 0)
        {
            Node current = queue.Dequeue();
            statesChecked++;

            if (statesChecked % 100 == 0)
            {
                Log($"  Progress: {statesChecked} states, {current.tilesVisited.Count}/9 tiles");
            }

            if (current.tilesVisited.Count == GRID_SIZE * GRID_SIZE)
            {
                solution = current;
                Log($"  FOUND SOLUTION at {statesChecked} states!");
                break;
            }

            Vector2Int[] directions = {
                Vector2Int.up,
                Vector2Int.down,
                Vector2Int.left,
                Vector2Int.right
            };

            foreach (Vector2Int dir in directions)
            {
                Vector2Int newPos = current.position + dir;

                if (newPos.x < 0 || newPos.x >= GRID_SIZE ||
                    newPos.y < 0 || newPos.y >= GRID_SIZE)
                    continue;

                Node child = new Node();
                child.position = newPos;
                child.tilesVisited = new List<Vector2Int>(current.tilesVisited);

                if (!child.tilesVisited.Contains(newPos))
                {
                    child.tilesVisited.Add(newPos);
                }

                string key = child.GetStateKey();

                if (!visited.ContainsKey(key))
                {
                    queue.Enqueue(child);
                    visited[key] = true;
                }
            }
        }

        Log("");

        if (solution != null)
        {
            optimalPath = solution.tilesVisited;
            int moves = optimalPath.Count - 1;

            Log("======================================");
            Log("  BFS SUCCESS!");
            Log("======================================");
            Log($"States checked: {statesChecked}");
            Log($"Optimal path: {moves} moves");
            Log($"Food needed: {moves * 2}");
            Log("");
            Log("Press V to VISUALIZE the path!");
            Log("(Animated step-by-step walkthrough)");
        }
        else
        {
            Log("======================================");
            Log("  BFS FAILED!");
            Log("======================================");
            Log($"States checked: {statesChecked}");
        }

        UpdateDisplay();
    }

    void StartAnimation()
    {
        if (optimalPath == null || optimalPath.Count == 0) return;

        isAnimating = true;
        animationStep = 0;
        animationTimer = 0f;
        showAnimationStep = true;

        Log("");
        Log("======================================");
        Log("  PATH VISUALIZATION STARTED");
        Log("======================================");
        Log("Watch the path animate!");
        Log("");
        Log("Controls:");
        Log("  ESC   - Stop animation");
        Log("  ARROW - Next step (manual)");

        UpdateDisplay();
    }

    void StopAnimation()
    {
        isAnimating = false;
        animationStep = 0;
        Log("");
        Log("Animation stopped.");
        UpdateDisplay();
    }

    void AdvanceAnimation()
    {
        if (animationStep < optimalPath.Count - 1)
        {
            animationStep++;
            showAnimationStep = true;
            UpdateDisplay();
        }
        else
        {
            StopAnimation();
            Log("Animation complete!");
            UpdateDisplay();
        }
    }

    void UpdateAnimation()
    {
        animationTimer += Time.deltaTime;

        // Blinking effect - toggle every 0.15 seconds
        if (animationTimer >= 0.15f)
        {
            showAnimationStep = !showAnimationStep;
            animationTimer = 0f;
            UpdateDisplay();
        }

        // Auto-advance to next step
        if (animationTimer >= animationSpeed)
        {
            AdvanceAnimation();
            animationTimer = 0f;
        }
    }

    void UpdateDisplay()
    {
        string output = "";

        // Title
        output += "======================================\n";
        if (isAnimating)
        {
            output += $"   VISUALIZING PATH - Step {animationStep + 1}/{optimalPath.Count}\n";
        }
        else
        {
            output += "       GAME GRID (3x3)\n";
        }
        output += "======================================\n";

        // Draw grid
        for (int y = GRID_SIZE - 1; y >= 0; y--)
        {
            output += "  ";
            for (int x = 0; x < GRID_SIZE; x++)
            {
                Vector2Int pos = new Vector2Int(x, y);

                if (isAnimating)
                {
                    // Animation mode
                    int pathIndex = optimalPath.IndexOf(pos);

                    if (pathIndex == animationStep && showAnimationStep)
                    {
                        output += "[@]"; // Current animated position (blinking)
                    }
                    else if (pathIndex >= 0 && pathIndex < animationStep)
                    {
                        output += $"<{pathIndex}>";  // Already visited (show step number)
                    }
                    else if (pathIndex >= 0 && pathIndex > animationStep)
                    {
                        output += " > "; // Future path
                    }
                    else
                    {
                        output += " . "; // Not on path
                    }
                }
                else
                {
                    // Normal mode
                    bool onPath = optimalPath != null && optimalPath.Contains(pos);

                    if (pos == playerPos)
                        output += "[P]";
                    else if (onPath && !explored.Contains(pos))
                        output += " * ";
                    else if (explored.Contains(pos))
                        output += " . ";
                    else
                        output += " ? ";
                }

                output += " ";
            }
            output += "\n";
        }

        output += "======================================\n\n";

        // Legend
        if (isAnimating)
        {
            output += "Animation Legend:\n";
            output += "  [@] = Current Position (blinking)\n";
            output += "  <#> = Visited (step number)\n";
            output += "   >  = Future Path\n";
            output += "   .  = Not on path\n\n";
        }
        else
        {
            output += "Legend:\n";
            output += "  [P] = Your Position\n";
            output += "   *  = Optimal Path\n";
            output += "   .  = Explored\n";
            output += "   ?  = Unexplored\n\n";
        }

        // Stats
        output += "======================================\n";
        output += "       STATISTICS\n";
        output += "======================================\n";
        output += $"Grid: {GRID_SIZE}x{GRID_SIZE}\n";
        output += $"Position: {playerPos}\n";
        output += $"Food: {food}/{STARTING_FOOD}\n";
        output += $"Explored: {explored.Count}/9 tiles\n";
        output += $"Your Moves: {playerMoves}\n";

        if (optimalPath != null)
        {
            int optimal = optimalPath.Count - 1;
            output += $"Optimal Moves: {optimal}\n";

            if (playerMoves > 0)
            {
                float eff = (optimal / (float)playerMoves) * 100f;
                output += $"Efficiency: {eff:F1}%\n";
            }
        }

        output += "======================================\n\n";

        // Animation status
        if (isAnimating)
        {
            Vector2Int currentPos = optimalPath[animationStep];
            output += "ANIMATION STATUS:\n";
            output += "--------------------------------------\n";
            output += $"Step: {animationStep + 1} of {optimalPath.Count}\n";
            output += $"Position: {currentPos}\n";
            output += $"Progress: {((animationStep + 1) / (float)optimalPath.Count * 100):F0}%\n";
            output += "\n";
            output += "ESC=Stop  ARROW=Next Step\n";
            output += "--------------------------------------\n\n";
        }

        // Log messages
        output += "MESSAGE LOG:\n";
        output += "--------------------------------------\n";
        int start = Mathf.Max(0, logMessages.Count - 12);
        for (int i = start; i < logMessages.Count; i++)
        {
            output += logMessages[i] + "\n";
        }

        if (outputText != null)
            outputText.text = output;
    }

    void Log(string msg)
    {
        logMessages.Add(msg);
        Debug.Log(msg);
    }

    // BFS Node class
    class Node
    {
        public Vector2Int position;
        public List<Vector2Int> tilesVisited = new List<Vector2Int>();

        public string GetStateKey()
        {
            string key = $"{position.x},{position.y}|";

            List<Vector2Int> sorted = new List<Vector2Int>(tilesVisited);
            sorted.Sort((a, b) => {
                if (a.x != b.x) return a.x.CompareTo(b.x);
                return a.y.CompareTo(b.y);
            });

            foreach (var tile in sorted)
            {
                key += $"{tile.x}{tile.y}";
            }

            return key;
        }
    }
}